﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Reflection;
using Ucfar.Util.Config;

namespace Ucfar.Application.Service
{
    public class DbContext
    {

        private static readonly string ConnectionString = Config.DefaultConnectionString;
        public static SqlConnection Open(bool mars = false)
        {
            var cs = ConnectionString;
            if (mars)
            {
                var scsb = new SqlConnectionStringBuilder(cs)
                {
                    MultipleActiveResultSets = true
                };
                cs = scsb.ConnectionString;
            }
            var connection = new SqlConnection(cs);
            connection.Open();
            return connection;
        }

    }
}
