﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Top.Api;
using Top.Api.Request;
using Top.Api.Response;
using Ucfar.Util;
using Ucfar.Util.Config;

namespace Ucfar.Application.Service
{
    public class SendSms
    {
        public static bool SendQuoteBase(string sjhm, string json)
        {
            string url = "https://eco.taobao.com/router/rest";
            string appkey = "23514717";
            string secret = "c52097d11512a4cf4c2b9948d5509187";
            ITopClient client = new DefaultTopClient(url, appkey, secret);
            AlibabaAliqinFcSmsNumSendRequest req = new AlibabaAliqinFcSmsNumSendRequest
            {
                Extend = "",
                SmsType = "normal",
                SmsFreeSignName = "提醒",
                SmsParam = json,
                RecNum = sjhm,
                SmsTemplateCode = "SMS_44320497" //QuoteBase模板
            };
            AlibabaAliqinFcSmsNumSendResponse rsp = client.Execute(req);
            return rsp.Result.Success;
        }
        public static bool SendExpire(string phonenum, string hphm, string endDate, string comPany, string agentName, string callNo)
        {
            string url = "https://eco.taobao.com/router/rest";
            string appkey = "23514717";
            string secret = "c52097d11512a4cf4c2b9948d5509187";
            ITopClient client = new DefaultTopClient(url, appkey, secret);
            AlibabaAliqinFcSmsNumSendRequest req = new AlibabaAliqinFcSmsNumSendRequest
            {
                Extend = "",
                SmsType = "normal",
                SmsFreeSignName = "提醒",
                SmsParam = "{HPHM:'" + hphm + "',EndDate:'" + endDate + "',ComPany:'" + comPany + "',AgentName:'" + agentName + "',CallNo:'" + callNo + "'}",
                RecNum = phonenum,
                SmsTemplateCode = "SMS_25135376" //到期提醒模板
            };
            AlibabaAliqinFcSmsNumSendResponse rsp = client.Execute(req);
            return rsp.Result.Success;
        }

        public static dynamic SendBirthday(string phonenum, string hphm, string comPany, string agentName, string callNo)
        {
            string url = "https://eco.taobao.com/router/rest";
            string appkey = "23514717";
            string secret = "c52097d11512a4cf4c2b9948d5509187";
            ITopClient client = new DefaultTopClient(url, appkey, secret);
            AlibabaAliqinFcSmsNumSendRequest req = new AlibabaAliqinFcSmsNumSendRequest
            {
                Extend = "",
                SmsType = "normal",
                SmsFreeSignName = "",
                SmsParam = "{HPHM:'" + hphm + "',ComPany:'" + comPany + "',AgentName:'" + agentName + "',CallNo:'" + callNo + "'}",
                RecNum = phonenum,
                SmsTemplateCode = "SMS_25090263" //生日模板
            };
            AlibabaAliqinFcSmsNumSendResponse rsp = client.Execute(req);
            return rsp.Body.ToJson();
        }


        private static string Url = "http://gw.api.taobao.com/router/rest";
        private static string AppKey = "AppKey";
        private static string AppSecret = "AppSecret";

        /// <summary>
        ///  发短信通用接口
        /// </summary>
        /// <param name="code">短信模板ID</param>
        /// <param name="smsParam">短信模板变量“验证码${code}，您正在进行${product}身份验证，打死不要告诉别人哦！”，
        ///     传参时需传入{"code":"1234","product":"alidayu"}</param>
        /// <param name="mobile">接收的手机号码,群发短信需传入多个号码，以英文逗号分隔，一次调用最多传入200个号码。</param>
        /// <param name="smsFreeSignName">短信签名</param>
        /// <param name="extend">公共回传参数，
        /// 在“消息返回”中会透传回该参数；举例：用户可以传入自己下级的会员ID，在消息返回时，
        /// 该会员ID会包含在内，用户可以根据该会员ID识别是哪位会员使用了你的应用</param>
        /// <returns>Json格式</returns> 
        public static dynamic SendAll(string code, string smsParam, string mobile, string smsFreeSignName = "", string extend = "")
        {
            ITopClient client = new DefaultTopClient(Url, AppKey, AppSecret);
            AlibabaAliqinFcSmsNumSendRequest req = new AlibabaAliqinFcSmsNumSendRequest
            {
                Extend = extend,
                SmsType = "normal",
                SmsFreeSignName = smsFreeSignName,
                SmsParam = smsParam,
                RecNum = mobile,
                SmsTemplateCode = code
            };
            AlibabaAliqinFcSmsNumSendResponse rsp = client.Execute(req);
            return rsp.Body.ToJson();
            //return rsp.SubErrMsg;
        }

        // var smsresult = SendSms.SendAll("SMS_25135376", "{\"HPHM\":\"" + hphm + "\",\"EndDate\":\"" + endDate + "\",\"ComPany\":\"" + comPany + "\",\"AgentName\":\"" + agentName + "\",\"CallNo\":\"" + callNo + "\"}", mobile,"","");

        public static int Send253(string asignName, string phone, string content)
        {
            string userName = Config.GetAppSetting("SmsUserName");
            string userPassWord = Config.GetAppSetting("SmsPassWord");
            int result = 0;
            string postUrl = "http://sms.253.com/msg/send";
            string postStrTpl = "un={0}&pw={1}&phone={2}&msg={3}&rd=1";
            UTF8Encoding encoding = new UTF8Encoding();
            byte[] postData = encoding.GetBytes(string.Format(postStrTpl, userName, userPassWord, phone, asignName + content));
            GC.Collect();
            HttpWebRequest myRequest = (HttpWebRequest)WebRequest.Create(postUrl);
            myRequest.KeepAlive = false;
            myRequest.Method = "POST";
            myRequest.ContentType = "application/x-www-form-urlencoded";
            myRequest.ContentLength = postData.Length;
            myRequest.Timeout = 5000;
            Stream newStream = myRequest.GetRequestStream();
            // Send the data.
            newStream.Write(postData, 0, postData.Length);
            newStream.Flush();
            newStream.Close();

            HttpWebResponse myResponse = (HttpWebResponse)myRequest.GetResponse();

            if (myResponse.StatusCode == HttpStatusCode.OK)
            {
                StreamReader reader = new StreamReader(myResponse.GetResponseStream(), Encoding.UTF8);
                var re = reader.ReadToEnd().Replace("\n", ",").Split(',');

                if (re[1] == "0")
                {
                    result = 0;//发送成功！
                }
                else
                {
                    result = -1;//发送失败！
                    if (re[1] == "109")
                    {
                        result = 109;//无发送额度（该用户可用短信数已使用完）,请及时充值！
                    }

                }
                myResponse.Close();
                myRequest.Abort();
                return result;
            }
            myRequest.Abort();
            myResponse.Close();
            return result;
        }
    }
}
