﻿using System.Collections.Generic;
using System.Data;
using Dapper;

namespace Ucfar.Application.Service
{
    public class DbHelper
    {
        public static int InsertMultiple<T>(string sql, List<T> entities, string connectionName = null) where T : class, new()
        {
            using (var cnn = DbContext.Open())
            {
                int records = 0;
                using (var trans = cnn.BeginTransaction())
                {
                    try
                    {
                        cnn.Execute(sql, entities, trans, 300, CommandType.Text);
                    }
                    catch (DataException ex)
                    {
                        trans.Rollback();
                        throw ex;
                    }
                    trans.Commit();
                }

                return records;
            }
        }
    }
}
