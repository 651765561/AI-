﻿using System;
using Dapper;
using Ucfar.Application.Entity;
using Ucfar.Application.Entity.SystemManage;
using Ucfar.Util;
using Ucfar.Util.Attributes;
using Ucfar.Util.Security;

namespace Ucfar.Application.Service.SystemManage
{
    public class LoginService
    {

        #region 用户登录

        /// <summary>
        /// 用户登录
        /// </summary>
        /// <param name="userName">用户名</param>
        /// <param name="password">密码</param>
        /// <returns></returns>
        public static int UserLogin(string userName, string password)
        {
            int msg = -1;
            if (string.IsNullOrEmpty(userName) || string.IsNullOrEmpty(password))
                return msg;
            MBaseLog log = new MBaseLog();
            MBaseUser u = GetModel(userName, DesEncrypt.Encrypt(password, "UcfarDES"));
            if (u == null)
            {
                log.ExecuteResult = -1;
                log.ExecuteResultJson = "用户名或密码不正确";
                msg = 3;
            }
            else
            {
                //写入cookie
                CookieHelper.WriteCookie(SysVisitor.CookieName, SysVisitor.CookieUserNameKey, u.UserCode, "", 1);
                CookieHelper.WriteCookie(SysVisitor.CookieRealNameKey, u.RealName, "", 1);
                CookieHelper.WriteCookie(SysVisitor.CookieMobileKey, u.Mobile, "", 1);
                CookieHelper.WriteCookie(SysVisitor.CookieTelKey, u.Telephone, "", 1);
                CookieHelper.WriteCookie(SysVisitor.CookieName, SysVisitor.CoookieIsAdminKey, u.IsAdmin.ToString(), "", 1);
                CookieHelper.WriteCookie(SysVisitor.CookieName, SysVisitor.CookieIsEnabledKey, u.IsEnable.ToString(), "", 1);
                var configJson = "{\"theme\":{\"title\":\"default\",\"name\":\"default\"},\"showType\":\"Tree\"}";
                var configCookie = CookieHelper.GetCookie(SysVisitor.CookieConfigJson);
                if (string.IsNullOrEmpty(configCookie))
                {
                    CookieHelper.WriteCookie(SysVisitor.CookieConfigJson, configJson, "", 365);
                }
                log.ExecuteResult = 1;
                log.ExecuteResultJson = "登录成功";
                msg = 1;
                if (!u.IsEnable && !u.IsAdmin)
                {
                    msg = 2;
                }
            }

            //写入日志
            //string userAgent = HttpContext.Current.Request.UserAgent ?? "无";

            log.OperateAccount = userName;
            log.OperateType = EnumAttribute.GetDescription(OperationType.Login);
            log.OperateTypeId = (int)OperationType.Login;
            LogService.WriteLog(log);
            return msg;

        }
        #endregion
        public static MBaseUser GetModel(string userName, string password)
        {
            using (var conn = DbContext.Open())
            {
                MBaseUser result = conn.QueryFirstOrDefault<MBaseUser>(@"SELECT * FROM Base_User where UserCode = @userName and Password=@password", new { userName, password });
                return result;
            }

        }

        /// <summary>
        /// 修改帐号密码
        /// </summary>
        /// <param name="userCode">用户代码</param>
        /// <param name="newpasswd">新密码</param>
        /// <param name="oldPassword"></param>
        /// <returns></returns>
        public static int EditPassword(string userCode, string newpasswd, string oldPassword)
        {
            if (!string.IsNullOrEmpty(newpasswd) && !string.IsNullOrEmpty(oldPassword))
            {
                MBaseLog log = new MBaseLog();
                oldPassword = DesEncrypt.Encrypt(oldPassword, "UcfarDES");
                MBaseUser u = GetModel(userCode, oldPassword);
                if (u != null)
                {
                    log.ExecuteResult = 1;
                    log.ExecuteResultJson = "修改密码成功";
                    log.OperateAccount = userCode;
                    log.OperateType = EnumAttribute.GetDescription(OperationType.Update);
                    log.OperateTypeId = (int)OperationType.Update;
                    LogService.WriteLog(log);

                    var newMd5Pass = DesEncrypt.Encrypt(newpasswd, "UcfarDES");
                    return UpdatePassword(userCode, newMd5Pass);

                }
                return -1;
            }
            return -1;
        }

        public static int UpdatePassword(string userCode, string password)
        {
            using (var conn = DbContext.Open())
            {
                var result = conn.Execute(@"update Base_User set Password=@password where UserCode = @userCode", new { password, userCode });
                return result;
            }
        }

    }
}
