﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using Ucfar.Application.Entity.SystemManage;
using Ucfar.Util;

namespace Ucfar.Application.Service.SystemManage
{
    public class CameraService
    {
        public static List<MtbCamera> GetAll()
        {
            using (var conn = DbContext.Open())
            {
                var result = conn.Query<MtbCamera>(@"SELECT * FROM TB_Camera").ToList();
                return result;
            }

        }

        public static string GetCrossingBySubCode(string subCode)
        {
            List<MtbCamera> result = GetAll();


            var crossing = result.Select(n => new
            {
                n.Id,
                n.CameraCode,
                n.CameraName,
                n.Sdk,
                n.Ip,
                n.Type,
                n.SubCode,
                n.IsEnable,
                @checked = subCode == n.SubCode
            });
            return crossing.ToJson();
        }

        public static string SetSubServerCrossing(string crsCode, string subCode)
        {
            var result = new JsonMessage();
            if (!string.IsNullOrEmpty(crsCode) && !string.IsNullOrEmpty(subCode))
            {
                SetSubCode(crsCode, subCode);
                result.Title = "1";
                result.Message = "监控设备分配成功";
            }
            else
            {
                result.Title = "0";
                result.Message = "未选择要分配的分布式服务器或未选择监控设备,请检查！";
            }
            return result.ToString();
        }
        public static bool SetSubCode(string crsCodes, string subCode)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"UPDATE TB_Crossing SET SubCode=@SubCode WHERE CrsCode in (" + crsCodes + ")", new { subCode });
                return a > 0;
            }
        }
        public static string JsonDataForEasyUIdataGrid(int pageindex = 1, int pagesize = 1, string sort = "Id", string order = "asc", string filterJson = "")
        {

            var builder = new SqlBuilder();
            var query = builder.AddTemplate("SELECT a.*,b.SubName  FROM TB_Camera a join TB_SubServer b on a.subCode=b.SubCode /**where**/ /**orderby**/" +
                                "OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY", new { skip = (pageindex - 1) * pagesize, take = pagesize });
            var count = builder.AddTemplate("SELECT Count(*) FROM TB_Camera a join TB_SubServer b on a.subCode=b.subCode /**where**/");
            if (!string.IsNullOrEmpty(filterJson))
            {
                dynamic filter = filterJson.ToJObject();
                string sql = "a.SubCode =" + filter.data + "";
                builder.Where(sql);

            }
            if (!string.IsNullOrEmpty(sort) && !string.IsNullOrEmpty(order))
            {
                builder.OrderBy("a." + sort + " " + order);
            }
            else
            {
                builder.OrderBy("a.Id asc");
            }

            List<dynamic> result;
            int resultCount;
            using (var conn = DbContext.Open())
            {
                result = conn.Query<dynamic>(query.RawSql, query.Parameters).ToList();
                resultCount = conn.ExecuteScalar<int>(count.RawSql, count.Parameters);
            }

            return Json.FormatJsonForEasyuiDataGrid(resultCount, result);

        }
        public static string AddCrossing(MtbCamera model)
        {
            var result = new JsonMessage();
            if (HasSubCode(model.CameraCode))
            {
                result.Message = "监控设备编码已存在！";
                result.Title = "0";
            }
            else
            {
                bool ok = Insert(model);
                result.Message = ok ? "添加成功。" : "添加失败。";
                result.Title = ok ? "1" : "0";

            }

            return result.ToString();


        }
        private static bool Insert(MtbCamera model)
        {
            using (var conn = DbContext.Open())
            {

                var a = conn.Execute(@"INSERT INTO TB_Camera
        (CameraCode,CameraName,Sdk,Ip,Port,UserName,Pwd,Channel,Type,Memo,SubCode,ChannelEx,IsEnable)
    VALUES
        (@CameraCode,@CameraName,@Sdk,@Ip,@Port,@UserName,@Pwd,@Channel,@Type,@Memo,@SubCode,@ChannelEx,@IsEnable)",
                    new { CrsCode = model.CameraCode, CameraName = model.CameraName, Sdk = model.Sdk, Ip = model.Ip, Port = model.Port, UserName = model.UserName, Pwd = model.Pwd, Channel = model.Channel, Type = model.Type, Memo = model.Memo, SubCode = model.SubCode, ChannelEx = model.ChannelEx, IsEnable = model.IsEnable });
                return a > 0;

            }
        }
        public static bool HasSubCode(string crsCode)
        {
            var list = GetAll();
            return list.Any(n => (n.CameraCode == crsCode));
        }
        public static string IsEnable(int id, string field, bool fieldValue)
        {
            var result = new JsonMessage();
            bool ok = UpdateField(id, field, fieldValue);
            result.Message = ok ? "设置成功。" : "设置失败。";
            result.Title = ok ? "1" : "0";
            return result.ToString();

        }
        private static bool UpdateField(int id, string field, bool fieldValue)
        {
            var sql = string.Empty;
            DynamicParameters para = new DynamicParameters();

            if (field == "IsEnable")
            {
                sql = @"update TB_Camera set IsEnable=@IsEnable where ID = @ID";
                para.Add("IsEnable", fieldValue);
                para.Add("ID", id);
            }
            using (var conn = DbContext.Open())
            {
                var result = conn.Execute(sql, para);
                return result > 0;
            }
        }
        public static string EditCrossing(MtbCamera model)
        {
            var result = new JsonMessage();

            bool ok = Update(model);
            result.Message = ok ? "修改成功。" : "修改失败。";
            result.Title = ok ? "1" : "0";


            return result.ToString();


        }
        private static bool Update(MtbCamera model)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"UPDATE TB_Camera SET 
 CameraCode=@CameraCode,CameraName=@CameraName,Sdk=@Sdk,Ip=@Ip,Port=@Port,UserName=@UserName,Pwd=@Pwd,Channel=@Channel,Type=@Type,Memo=@Memo,SubCode=@SubCode,ChannelEx=@ChannelEx,IsEnable=@IsEnable  
 WHERE ID=@ID",
                    new { CameraCode = model.CameraCode, CameraName = model.CameraName, Sdk = model.Sdk, Ip = model.Ip, Port = model.Port, UserName = model.UserName, Pwd = model.Pwd, Channel = model.Channel, Type = model.Type, Memo = model.Memo, SubCode = model.SubCode, ChannelEx = model.ChannelEx, IsEnable = model.IsEnable, ID = model.Id });
                return a > 0;
            }
        }
        public static string DeleteCrossing(int id)
        {
            var result = new JsonMessage();
            bool ok = Delete(id);
            result.Message = ok ? "删除成功。" : "删除失败。";
            result.Title = ok ? "1" : "0";
            return result.ToString();


        }
        private static bool Delete(int id)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"Delete from TB_Camera where ID=@ID", new { id });
                return a > 0;
            }
        }
      
    }
}
