﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using Ucfar.Application.Entity.SystemManage;
using Ucfar.Util;

namespace Ucfar.Application.Service.SystemManage
{
    public class CrossingCameraService
    {
        public static string GetModelByCrsCode(string crsCode)
        {
            using (var conn = DbContext.Open())
            {
                dynamic json = new ExpandoObject();
                var list = conn.Query<MtbCrossingCamera>(@"select * from TB_CrossingCamera where CrsCode=@CrsCode", new { CrsCode = crsCode }).ToList();
                foreach (var modle in list)
                {

                    switch (modle.WhichOne)
                    {
                        case 1:
                            json.CameraIp1 = modle.CameraIp;
                            break;
                        case 2:
                            json.CameraIp2 = modle.CameraIp;
                            break;
                        case 3:
                            json.CameraIp3 = modle.CameraIp;
                            break;
                    }


                }
                return Json.ToJson(json);
            }
        }
        public static string Bind(List<dynamic> list,string crsCode)
        {
            var result = new JsonMessage();

            bool ok = Insert(list, crsCode);
            result.Message = ok ? "绑定成功。" : "绑定失败。";
            result.Success = ok ;
            return result.ToString();


        }
        private static bool Insert(List<dynamic> list,string crsCode)
        {
            using (var cnn = DbContext.Open())
            {
                int records;
                using (var trans = cnn.BeginTransaction())
                {
                    try
                    {
                        cnn.Execute(@"Delete from TB_CrossingCamera where crsCode=@crsCode", new { crsCode = crsCode },trans,0,CommandType.Text);
                        string sql = @"INSERT INTO TB_CrossingCamera (CrsCode,CrsIp,CameraIp,WhichOne) VALUES (@CrsCode,@CrsIp,@CameraIp,@WhichOne)";
                        records=cnn.Execute(sql, list, trans, 300, CommandType.Text);
                    }
                    catch (DataException ex)
                    {
                        trans.Rollback();
                        throw ex;
                    }
                    trans.Commit();
                }

                return records>0;
            }
        }
   
    }
}
