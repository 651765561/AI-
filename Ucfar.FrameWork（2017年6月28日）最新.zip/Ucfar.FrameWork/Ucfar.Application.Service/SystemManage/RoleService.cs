﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using Ucfar.Application.Entity.SystemManage;
using Ucfar.Util;

namespace Ucfar.Application.Service.SystemManage
{
    public class RoleService
    {
        public static List<MBaseRole> GetAll()
        {
            using (var conn = DbContext.Open())
            {
                var result = conn.Query<MBaseRole>(@"SELECT * FROM Base_Role order by SortCode").ToList();
                return result;
            }

        }
        public static string GetRoles()
        {
            using (var conn = DbContext.Open())
            {
                var result = conn.Query(@"SELECT RoleCode,RoleName,IsDefault FROM Base_Role order by SortCode").ToList();
                return result.ToJson();
            }

        }
        public static string GetRolesByUserCode(string userCode)
        {
            using (var conn = DbContext.Open())
            {
                var result = conn.Query(@"SELECT a.RoleCode,a.RoleName FROM Base_Role a join Base_UserRoleMap b on a.RoleCode=b.RoleCode  where b.UserCode=@UserCode order by a.SortCode", new { userCode }).ToList();
                return result.ToJson();
            }

        }
        public static string GetRolesBySubCode(string subCode)
        {
            using (var conn = DbContext.Open())
            {
                var result = conn.Query(@"SELECT a.RoleCode,a.RoleName FROM Base_Role a join TB_SubServerRoleMap b on a.RoleCode=b.RoleCode  where b.SubCode=@SubCode", new { subCode }).ToList();
                return result.ToJson();
            }

        }
        /// <summary>
        /// 根据用户名获取角色代码集合
        /// </summary>
        /// <param name="userCode"></param>
        /// <returns></returns>
        public static List<string> GetRolesBy(string userCode)
        {
            using (var conn = DbContext.Open())
            {
                var result = conn.Query<string>(@"SELECT roleCode FROM Base_UserRoleMap where userCode = @userCode", new { userCode }).ToList();
                return result;
            }
        }
        public static string JsonDataForEasyUIdataGrid(int pageindex = 1, int pagesize = 1, string sort = "Id", string order = "asc", string filterJson = "")
        {

            var builder = new SqlBuilder();
            var query = builder.AddTemplate("SELECT * FROM Base_Role /**where**/ /**orderby**/" +
                                "OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY", new { skip = (pageindex - 1) * pagesize, take = pagesize });
            var count = builder.AddTemplate("SELECT Count(*) FROM Base_Role /**where**/");

            if (!string.IsNullOrEmpty(filterJson))
            {
                List<dynamic> filterList = filterJson.ToList<dynamic>();

                foreach (dynamic f in filterList)
                {
                    string sql = f.field + "='" + f.data + "'";
                    builder.Where(sql);
                }


            }
            if (!string.IsNullOrEmpty(sort) && !string.IsNullOrEmpty(order))
            {
                builder.OrderBy(sort + " " + order);
            }
            else
            {
                builder.OrderBy("SortCode asc");
            }

            List<MBaseRole> result;
            int resultCount;
            using (var conn = DbContext.Open())
            {
                result = conn.Query<MBaseRole>(query.RawSql, query.Parameters).ToList();
                resultCount = conn.ExecuteScalar<int>(count.RawSql, count.Parameters);
            }

            return Json.FormatJsonForEasyuiDataGrid(resultCount, result);

        }

        public static string EditRole(MBaseRole model)
        {
            var result = new JsonMessage();

            bool ok = Update(model);
            result.Message = ok ? "修改成功。" : "修改失败。";
            result.Title = ok ? "1" : "0";


            return result.ToString();

        }
        public static bool Update(MBaseRole model)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"UPDATE Base_Role SET  RoleCode=@RoleCode,RoleName=@RoleName,Description=@Description,SortCode=@SortCode,IsDefault=@IsDefault  WHERE ID=@ID",
        new { model.RoleCode, model.RoleName, model.Description, model.SortCode, model.IsDefault, model.ID });
                return a > 0;
            }
        }
        public static string AddRole(MBaseRole entity)
        {
            var result = new JsonMessage();
            if (HasRole(entity))
            {
                result.Message = "权限名称或编码已存在！";
                result.Title = "0";
            }
            else
            {
                bool ok = Insert(entity);
                result.Message = ok ? "添加成功。" : "添加失败。";
                result.Title = ok ? "1" : "0";

            }

            return result.ToString();
        }
        private static bool HasRole(MBaseRole entity)
        {
            var btns = GetAll();
            return btns.Any(n => (n.RoleCode == entity.RoleCode || n.RoleName == entity.RoleName));
        }
        private static bool Insert(MBaseRole model)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"INSERT INTO Base_Role (RoleCode,RoleName,Description,SortCode,IsDefault) VALUES (@RoleCode,@RoleName,@Description,@SortCode,@IsDefault)",
        new { model.RoleCode, model.RoleName, model.Description, model.SortCode, model.IsDefault });
                return a > 0;
            }
        }
        public static string DeleteRole(int roleId)
        {
            var result = new JsonMessage();

            bool ok = Delete(roleId);
            result.Message = ok ? "删除成功。" : "删除失败。";
            result.Title = ok ? "1" : "0";


            return result.ToString();
        }
        private static bool Delete(int id)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"Delete from Base_Role where ID = @ID", new { ID = id });
                return a > 0;
            }
        }

        public static string SetRoles(string roleCode, string userCode)
        {
            var result = new JsonMessage();

            List<MBaseUserRoleMap> modeList = new List<MBaseUserRoleMap>();
            if (!string.IsNullOrEmpty(roleCode))
            {
                int rows;
                foreach (var i in roleCode.Split(','))
                {
                    MBaseUserRoleMap model = new MBaseUserRoleMap
                    {
                        RoleCode = i,
                        UserCode = userCode
                    };
                    modeList.Add(model);
                }
                using (var conn = DbContext.Open())
                {
                    //开户事务
                    var trans = conn.BeginTransaction();
                    rows = conn.Execute(@"Delete from Base_UserRoleMap where UserCode=@UserCode", new { userCode }, trans);
                    if (rows >= 0)
                    {
                        rows =
                            conn.Execute(
                                @"INSERT INTO Base_UserRoleMap (UserCode,RoleCode) VALUES (@UserCode,@RoleCode)",
                                modeList, trans);
                        if (rows >= 0)
                            trans.Commit();
                        else
                            trans.Rollback();
                    }
                    else
                        trans.Rollback();
                }
                result.Message = rows >= 0 ? "角色设置成功。" : "角色设置失败。";
                result.Title = rows >= 0 ? "1" : "0";
            }
            else
            {
                result.Message = "角色设置失败。请选择帐户！";
                result.Title = "0";
            }

            return result.ToString();

        }
        public static string SetRoleUsers(string userCodes, string roleCode)
        {
            var result = new JsonMessage();

            List<MBaseUserRoleMap> modeList = new List<MBaseUserRoleMap>();
            if (!string.IsNullOrEmpty(userCodes))
            {

                int rows;
                foreach (var i in userCodes.Split(','))
                {
                    MBaseUserRoleMap model = new MBaseUserRoleMap
                    {
                        RoleCode = roleCode,
                        UserCode = i
                    };
                    modeList.Add(model);
                }
                using (var conn = DbContext.Open())
                {
                    //开户事务
                    var trans = conn.BeginTransaction();
                    rows = conn.Execute(@"Delete from Base_UserRoleMap where RoleCode=@RoleCode", new { roleCode }, trans);
                    if (rows >= 0)
                    {
                        rows = conn.Execute(@"INSERT INTO Base_UserRoleMap (UserCode,RoleCode) VALUES (@UserCode,@RoleCode)", modeList, trans);
                        if (rows >= 0)
                            trans.Commit();
                        else
                            trans.Rollback();
                    }
                    else
                        trans.Rollback();
                }
                result.Message = rows >= 0 ? "批量帐户设置成功。" : "批量帐户设置失败。";
                result.Title = rows >= 0 ? "1" : "0";
            }
            else
            {
                result.Message = "批量帐户设置失败。请选择帐户！";
                result.Title = "0";

            }



            return result.ToString();

        }
        public static string SetSubServerRoles(string roleCode, string subCode)
        {
            int rows;
            var result = new JsonMessage();
            List<MtbSubServerRoleMap> modeList = new List<MtbSubServerRoleMap>();
            if (!string.IsNullOrEmpty(roleCode))
            {
                foreach (var i in roleCode.Split(','))
                {
                    MtbSubServerRoleMap model = new MtbSubServerRoleMap
                    {
                        RoleCode = i,
                        SubCode = subCode
                    };
                    modeList.Add(model);
                }
                
                using (var conn = DbContext.Open())
                {
                    //开户事务
                    var trans = conn.BeginTransaction();
                    rows = conn.Execute(@"Delete from TB_SubServerRoleMap where SubCode=@SubCode", new { subCode }, trans);
                    if (rows >= 0)
                    {
                        rows = conn.Execute(@"INSERT INTO TB_SubServerRoleMap (SubCode,RoleCode) VALUES (@SubCode,@RoleCode)", modeList, trans);
                        if (rows >= 0)
                            trans.Commit();
                        else
                            trans.Rollback();
                    }
                    else
                        trans.Rollback();
                }
                result.Message = rows >= 0 ? "角色设置成功。" : "角色设置失败。";
                result.Title = rows >= 0 ? "1" : "0";

            }
            else
            {
                using (var conn = DbContext.Open())
                {
                   rows= conn.Execute(@"Delete from TB_SubServerRoleMap where SubCode=@SubCode", new {subCode});
                }
                result.Message = rows >= 0 ? "角色设置成功。" : "角色设置失败。";
                result.Title = rows >= 0 ? "1" : "0";

            }
            return result.ToString();

        }
    }
}
