﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using Ucfar.Application.Entity.SystemManage;
using Ucfar.Util;

namespace Ucfar.Application.Service.SystemManage
{
    public class SubServerService
    {
        public static List<MtbSubServer> GetAll()
        {
            using (var conn = DbContext.Open())
            {
                var result = conn.Query<MtbSubServer>(@"SELECT * FROM TB_SubServer").ToList();
                return result;
            }
        }
        public static string  GetSubIpBySubCode(string subCode)
        {
            using (var conn = DbContext.Open())
            {
                var result = conn.ExecuteScalar<string>(@"SELECT SubIp FROM TB_SubServer where subCode=@subCode",new {subCode});
                return result;
            }
        }
        public static string AddSubServer(MtbSubServer model, string roleIds)
        {
            var result = new JsonMessage();
            if (HasSubCode(model.SubCode,model.ID))
            {
                result.Message = "服务器编码已存在！";
                result.Title = "0";
            }
            else
            {

                bool ok = Insert(model);

                if (!string.IsNullOrEmpty(roleIds))
                {
                    var roleIdArr = roleIds.Split(',');
                    var modeList = new List<MtbSubServerRoleMap>();
                    MtbSubServerRoleMap list = new MtbSubServerRoleMap();
                    foreach (var roleCode in roleIdArr)
                    {
                        list.SubCode = model.SubCode;
                        list.RoleCode = roleCode;
                        modeList.Add(list);
                    }

                    InsertSubServerRole(modeList);
                }
                result.Message = ok ? "添加成功。" : "添加失败。";
                result.Title = ok ? "1" : "0";

            }

            return result.ToString();


        }
        public static bool HasSubCode(string subCode,int id)
        {
            var subServerList = GetAll();
            return subServerList.Any(n => n.ID != id && (n.SubCode == subCode));
        }
        private static bool Insert(MtbSubServer model)
        {
            using (var conn = DbContext.Open())
            {

                var a = conn.Execute(@"INSERT INTO TB_SubServer (SubCode,SubName,SubIp,IsEnable,OrganizeCode) VALUES (@SubCode,@SubName,@SubIp,@IsEnable,@OrganizeCode)",
         new { model.SubCode, model.SubName, model.SubIp, model.IsEnable, model.OrganizeCode });
                return a > 0;
            }
        }
        private static void InsertSubServerRole(List<MtbSubServerRoleMap> modelList)
        {
            using (var conn = DbContext.Open())
            {

                conn.Execute(@"INSERT  TB_SubServerRoleMap(SubCode,RoleCode) VALUES (@SubCode,@RoleCode)", modelList);

            }
        }
        public static string EditSubServer(MtbSubServer model)
        {
            var result = new JsonMessage();
            if (HasSubCode(model.SubCode, model.ID))
            {
                result.Message = "服务器编码已存在,不能重复！";
                result.Title = "0";
            }
            else
                {
                bool ok = Update(model);
                result.Message = ok ? "修改成功。" : "修改失败。";
                result.Title = ok ? "1" : "0";
            }
           
            return result.ToString();


        }
        private static bool Update(MtbSubServer model)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"UPDATE TB_SubServer SET SubCode=@SubCode,SubName=@SubName,SubIp=@SubIp,OrganizeCode=@OrganizeCode,IsEnable=@IsEnable WHERE ID=@ID",
                new { model.SubCode, model.SubName, model.SubIp, model.OrganizeCode, model.IsEnable, model.ID });
                return a > 0;
            }
        }
        public static string DeleteSubServer(int id)
        {
            var result = new JsonMessage();
            bool ok = Delete(id);
            result.Message = ok ? "删除成功。" : "删除失败。";
            result.Title = ok ? "1" : "0";
            return result.ToString();


        }
        private static bool Delete(int id)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"Delete from TB_SubServer where ID=@ID", new { id });
                return a > 0;
            }
        }
        public static string IsEnable(int id, string field, bool fieldValue)
        {
            var result = new JsonMessage();
            bool ok = UpdateField(id, field, fieldValue);
            result.Message = ok ? "设置成功。" : "设置失败。";
            result.Title = ok ? "1" : "0";
            return result.ToString();

        }
        private static bool UpdateField(int id, string field, bool fieldValue)
        {
            var sql = string.Empty;
            DynamicParameters para = new DynamicParameters();
         
            if (field == "IsEnable")
            {
                sql = @"update TB_SubServer set IsEnable=@IsEnable where ID = @ID";
                para.Add("IsEnable", fieldValue);
                para.Add("ID", id);
            }
            using (var conn = DbContext.Open())
            {
                var result = conn.Execute(sql, para);
                return result > 0;
            }
        }
        public static string JsonDataForEasyUIdataGrid(int pageindex = 1, int pagesize = 1, string sort = "Id", string order = "asc", string filterJson = "")
        {

            var builder = new SqlBuilder();
            var query = builder.AddTemplate("SELECT a.ID,a.SubCode,a.SubName,a.SubIp,a.IsOnline,a.IsEnable,a.OrganizeCode,b.OrganizeName  FROM TB_SubServer a join Base_Organize b on a.OrganizeCode=b.OrganizeCode /**where**/ /**orderby**/" +
                                "OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY", new { skip = (pageindex - 1) * pagesize, take = pagesize });
            var count = builder.AddTemplate("SELECT Count(*) FROM TB_SubServer a join Base_Organize b on a.OrganizeCode=b.OrganizeCode /**where**/");
            if (!string.IsNullOrEmpty(filterJson))
            {
                dynamic filter = filterJson.ToJObject();
                string sql = "a.OrganizeCode in(" + filter.data + ")";
                builder.Where(sql);

            }
            if (!string.IsNullOrEmpty(sort) && !string.IsNullOrEmpty(order))
            {
                builder.OrderBy("a." + sort + " " + order);
            }
            else
            {
                builder.OrderBy("a.SubCode asc");
            }

            List<dynamic> result;
            int resultCount;
            using (var conn = DbContext.Open())
            {
                result = conn.Query<dynamic>(query.RawSql, query.Parameters).ToList();
                resultCount = conn.ExecuteScalar<int>(count.RawSql, count.Parameters);
            }

            return Json.FormatJsonForEasyuiDataGrid(resultCount, result);

        }

        public static string BuildTreeJson()
        {
            return GetTree(GetAll()).ToList().ToJson();
        }
        private static IEnumerable<dynamic> GetTree(List<MtbSubServer> all)
        {
            var menus =
                all .Select(n => new
                    {
                        id=n.SubCode,
                        text = n.SubName,
                        iconCls = "icon16_drive_network"
                    });
            return menus;
        }
        public static List<string> GetSubCodeByRoleCodes(List<string> roleCodes)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Query<string>(@"select distinct SubCode from TB_SubServerRoleMap where RoleCode in @RoleCode",new { RoleCode=roleCodes }).ToList();
                return a;
            }
        }
    }
}
