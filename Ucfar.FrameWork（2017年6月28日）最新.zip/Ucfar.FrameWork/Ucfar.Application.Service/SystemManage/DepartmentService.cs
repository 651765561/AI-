﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using Ucfar.Application.Entity.SystemManage;
using Ucfar.Util;

namespace Ucfar.Application.Service.SystemManage
{
    public class DepartmentService
    {
        public static List<MBaseOrganize> GetAll()
        {
            using (var conn = DbContext.Open())
            {
                var result = conn.Query<MBaseOrganize>(@"SELECT * FROM Base_Organize order by SortCode").ToList();
                return result;
            }

        }
        public static string BuildTreeGridJson()
        {
            return GetTreeGridList(GetAll(), "0").ToList().ToJson();
        }
        public static string BuildTreeJson()
        {
            return GetTree(GetAll(), "0").ToList().ToJson();
        }
        private static IEnumerable<dynamic> GetTreeGridList(List<MBaseOrganize> all, string parentCode)
        {
            var menus =
                all.Where(n => n.ParentCode == parentCode)
                    .Select(n => new
                    {
                        n.ID,
                        n.OrganizeCode,
                        n.OrganizeName,
                        n.ParentCode,
                        n.SortCode,
                        iconCls = parentCode == "0"
                                                ? "icon16_sitemap"
                                                : (all.Any(a => a.ParentCode == n.OrganizeCode) ? "icon16_building" : "icon16_server"),
                        state =
                                            parentCode == "0"
                                                ? "open"
                                                : (all.Any(a => a.ParentCode == n.OrganizeCode) ? "closed" : "open"),
                        n.SubOrganizeName,
                        children = GetTreeGridList(all, n.OrganizeCode)
                    });
            return menus;
        }
        private static IEnumerable<dynamic> GetTree(List<MBaseOrganize> all, string parentCode)
        {
            var menus =
                all.Where(n => n.ParentCode == parentCode)
                    .Select(n => new
                    {
                        n.OrganizeCode,
                        text=n.OrganizeName,
                        iconCls = parentCode == "0"
                                                ? "icon16_sitemap"
                                                : (all.Any(a => a.ParentCode == n.OrganizeCode) ? "icon16_building" : "icon16_server"),
                        state =
                                            parentCode == "0"
                                                ? "open"
                                                : (all.Any(a => a.ParentCode == n.OrganizeCode) ? "closed" : "open"),
                        children = GetTree(all, n.OrganizeCode)
                    });
            return menus;
        }
        public static string BuilOrgTreeJson()
        {
            return GetListOrgChart(GetAll(), "0").ToList().ToJson().TrimStart('[').TrimEnd(']');
        }
        private static IEnumerable<dynamic> GetListOrgChart(List<MBaseOrganize> all, string parentCode)
        {
            var menus =
                all.Where(n => n.ParentCode == parentCode)
                    .Select(n => new
                    {
                        name=n.OrganizeName,
                        title=n.SubOrganizeName,
                        children = GetListOrgChart(all, n.OrganizeCode)
                    });
            return menus;
        }
        public static string AddOrg(MBaseOrganize entity)
        {
            var result = new JsonMessage();
            if (HasButton(entity))
            {
                result.Message = "机构名称或编码已存在！";
                result.Title = "0";
            }
            else
            {
                bool ok = Insert(entity);
                result.Message = ok ? "添加成功。" : "添加失败。";
                result.Title = ok ? "1" : "0";

            }

            return result.ToString();
        }
        private static bool HasButton(MBaseOrganize entity)
        {
            var btns = GetAll();
            return btns.Any(n => n.ID!=entity.ID && (n.OrganizeCode == entity.OrganizeCode || n.OrganizeName == entity.OrganizeName));
        }
        private static bool Insert(MBaseOrganize model)
        {
            using (var conn = DbContext.Open())
            {

                var a = conn.Execute(@"INSERT  Base_Organize (ParentCode,SortCode,OrganizeName,SubOrganizeName,OrganizeCode) VALUES
        (@ParentCode,@SortCode,@OrganizeName,@SubOrganizeName,@OrganizeCode)",
        new {model.ParentCode, model.SortCode, model.OrganizeName, model.SubOrganizeName,model.OrganizeCode});
                return a > 0;
            }
        }
        public static string EditOrg(MBaseOrganize entity)
        {
            var result = new JsonMessage();
            if (HasButton(entity))
            {
                result.Message = "机构名称或编码已存在！";
                result.Title = "0";
            }
            else
            {
                bool ok = Update(entity);
                result.Message = ok ? "修改成功。" : "修改失败。";
                result.Title = ok ? "1" : "0";

            }
          
            return result.ToString();
        }
        private static bool Update(MBaseOrganize model)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"UPDATE Base_Organize SET ParentCode=@ParentCode,SortCode=@SortCode,OrganizeName=@OrganizeName,SubOrganizeName=@SubOrganizeName,OrganizeCode=@OrganizeCode WHERE ID=@ID",
        new {model.ParentCode, model.SortCode, model.OrganizeName, model.SubOrganizeName, model.OrganizeCode,model.ID });
                return a > 0;
            }
        }
        public static string DelOrg(string id)
        {
            var result = new JsonMessage();
            bool ok = Delete(id);
            result.Message = ok ? "删除成功。" : "删除失败。";
            result.Title = ok ? "1" : "0";
            return result.ToString();
        }
        private static bool Delete(string id)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"Delete from Base_Organize where ID=@ID", new { ID = id });
                return a > 0;
            }
        }
    }
}
