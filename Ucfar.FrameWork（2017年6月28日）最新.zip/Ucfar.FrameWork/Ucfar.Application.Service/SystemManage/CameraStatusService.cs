﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using Ucfar.Application.Entity.SystemManage;
using Ucfar.Util;
using System.Configuration;
using System.Data;

namespace Ucfar.Application.Service.SystemManage
{
    public class CameraStatusService
    {
        string sqlConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        #region 自定义方法
        public List<Entity.SystemManage.Partial.TB_CameraStatus> Search(string startDate, string endDate)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append(" select ROW_NUMBER()  over (order by id) as RowNumber ,CONVERT(varchar(100), Stime, 23) as StimeStr, * from TB_CameraStatus ");
            if (startDate != "" && endDate != "")
            {
                strSql.Append(" where CONVERT(varchar(100), Stime, 23) between '" + Convert.ToDateTime(startDate).ToString("yyyy-MM-dd") + "' and '" +
                    Convert.ToDateTime(endDate).ToString("yyyy-MM-dd") + "' ");
            }

            var dt = Tools.getDataSet(strSql.ToString(), sqlConnectionString).Tables[0];
            List<Entity.SystemManage.Partial.TB_CameraStatus> list = new List<Entity.SystemManage.Partial.TB_CameraStatus>();
            list = ConvertToList(dt);
            return list.ToList();
        }

        private List<Entity.SystemManage.Partial.TB_CameraStatus> ConvertToList(DataTable dt)
        {
            List<Entity.SystemManage.Partial.TB_CameraStatus> list = new List<Entity.SystemManage.Partial.TB_CameraStatus>();
            if (dt != null && dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    var r = dt.Rows[i];
                    var m = DataRowToModel(r);
                    list.Add(m);
                }
            }
            return list;
        }

        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Entity.SystemManage.Partial.TB_CameraStatus DataRowToModel(DataRow row)
        {
            Entity.SystemManage.Partial.TB_CameraStatus model = new Entity.SystemManage.Partial.TB_CameraStatus();
            if (row != null)
            {
                if (row.Table.Columns.Contains("StimeStr") && row["StimeStr"] != null)
                {
                    model.StimeStr = row["StimeStr"].ToString();

                }
                if (row.Table.Columns.Contains("RowNumber") && row["RowNumber"] != null)
                {
                    model.RowNumber = row["RowNumber"].ToString();

                }
                if (row["Id"] != null && row["Id"].ToString() != "")
                {
                    model.Id = int.Parse(row["Id"].ToString());
                }
                if (row["CameraCode"] != null)
                {
                    model.CameraCode = row["CameraCode"].ToString();
                }
                if (row["CameraName"] != null)
                {
                    model.CameraName = row["CameraName"].ToString();
                }
                if (row["CameraIp"] != null)
                {
                    model.CameraIp = row["CameraIp"].ToString();
                }
                if (row["CameraChannel"] != null)
                {
                    model.CameraChannel = row["CameraChannel"].ToString();
                }
                if (row["Status"] != null && row["Status"].ToString() != "")
                {
                    model.Status = int.Parse(row["Status"].ToString());
                }
                if (row["Stime"] != null && row["Stime"].ToString() != "")
                {
                    model.StimeII = DateTime.Parse(row["Stime"].ToString()).ToString("yyyy-MM-dd HH:mm:ss");
                    model.Stime = DateTime.Parse(row["Stime"].ToString());
                }
                if (row["Picture"] != null)
                {
                    model.Picture = row["Picture"].ToString();
                }
                if (row["Notify"] != null && row["Notify"].ToString() != "")
                {
                    model.Notify = int.Parse(row["Notify"].ToString());
                }
            }
            return model;
        }
        #endregion
        public static string JsonDataForEasyUIdataGrid(int isHandle, int isCallBack, int pageindex = 1, int pagesize = 1, string sort = "Id", string order = "desc", string filterJson = "")
        {

            var builder = new SqlBuilder();
            var query = builder.AddTemplate("SELECT  * FROM TB_CameraStatus  /**where**/ /**orderby**/" +
                                            "OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY", new { skip = (pageindex - 1) * pagesize, take = pagesize });
            var count = builder.AddTemplate("SELECT Count(*) FROM TB_CameraStatus /**where**/");
          
            if (!string.IsNullOrEmpty(filterJson))
            {
                List<dynamic> filterList = filterJson.ToList<dynamic>();
                string dtStart = "";
                string dtEnd = "";
                foreach (dynamic f in filterList)
                {
                    string field = f.field;
                    string data = f.data;

                    if (!string.IsNullOrEmpty(data))
                    {
                        switch (field)
                        {
                            
                            case "dtStart":
                                dtStart = data;
                                break;
                            case "dtEnd":
                                dtEnd = data;
                                break;
                            case "Status":
                                if (data != "100")
                                {
                                    string sql1 = $"Status={Convert.ToInt32(data)}";
                                    builder.Where(sql1);
                                }
                                break;
                           

                        }

                    }
                }
                if (!string.IsNullOrEmpty(dtStart) && !string.IsNullOrEmpty(dtEnd))
                {
                    string sql2 = $"Stime between'{dtStart}' and '{dtEnd}'";
                    builder.Where(sql2);
                }

            }
            if (!string.IsNullOrEmpty(sort) && !string.IsNullOrEmpty(order))
            {
                builder.OrderBy(sort + " " + order);
            }
            else
            {
                builder.OrderBy("Id desc");
            }

            List<MtbCameraStatus> result;
            int resultCount;
            using (var conn = DbContext.Open())
            {
                result = conn.Query<MtbCameraStatus>(query.RawSql, query.Parameters).ToList();
                resultCount = conn.ExecuteScalar<int>(count.RawSql, count.Parameters);
            }

            return Json.FormatJsonForEasyuiDataGrid(resultCount, result);

        }
    }
}
