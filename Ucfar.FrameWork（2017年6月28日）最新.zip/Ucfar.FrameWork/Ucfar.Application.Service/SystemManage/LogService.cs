﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using Newtonsoft.Json;
using Ucfar.Application.Entity.SystemManage;
using Ucfar.Util;
using Ucfar.Util.Extension;
using Ucfar.Util.WebControl;

namespace Ucfar.Application.Service.SystemManage
{
    /// <summary>
    ///     描 述：系统日志
    /// </summary>
    public class LogService
    {
        #region 获取数据
        //var queryParam = queryJson.ToJObject();
        //if (!queryParam["StartTime"].IsEmpty() && !queryParam["EndTime"].IsEmpty())
        //builder.Where("OperateTime >= @StartTime and OperateTime<=@EndTime", new { StartTime = startTime, EndTime = endTime });
        public static string JsonDataForEasyUIdataGrid(int pageindex = 1, int pagesize = 1, string sort = "Id", string order = "desc", string filterJson = "")
        {

            var builder = new SqlBuilder();
            var query = builder.AddTemplate("SELECT * FROM Base_Log /**where**/ /**orderby**/" +
                                "OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY", new { skip = (pageindex - 1) * pagesize, take = pagesize });
            var count = builder.AddTemplate("SELECT Count(*) FROM Base_Log /**where**/");
            var userName = SysVisitor.Instance.UserName;
            if (userName != "system")
            {
                string sql = " OperateAccount != @OperateAccount";
                builder.Where(sql, new { OperateAccount = "system" });
            }
            if (!string.IsNullOrEmpty(filterJson))
            {
                List<dynamic> filterList = filterJson.ToList<dynamic>();

                foreach (dynamic jsonVaule in filterList)
                {
                    string operateAccount = jsonVaule.OperateAccount;
                    string operateTime = jsonVaule.OperateTime;
                    if (!string.IsNullOrEmpty(operateAccount))
                    {
                        string sql = "OperateAccount=@OperateAccount2";
                        builder.Where(sql, new { OperateAccount2 = operateAccount });
                    }
                    if (!string.IsNullOrEmpty(operateTime))
                    {
                        string sql = "OperateTime between  @StartTime and @EndTime";
                        var startTime = operateTime.Split('|')[0];
                        var endTime = operateTime.Split('|')[1];
                        builder.Where(sql, new { startTime, endTime });
                    }
                }
                {


                    //string sql = jsonVaule.OperateAccount + "='" + f.data + "'";
                    //builder.Where(sql);
                }


            }
            if (!string.IsNullOrEmpty(sort) && !string.IsNullOrEmpty(order))
            {
                builder.OrderBy(sort + " " + order);
            }
            else
            {
                builder.OrderBy("ID Desc");
            }

            List<MBaseLog> result;
            int resultCount;
            using (var conn = DbContext.Open())
            {
                result = conn.Query<MBaseLog>(query.RawSql, query.Parameters).ToList();
                resultCount = conn.ExecuteScalar<int>(count.RawSql, count.Parameters);
            }

            return Json.FormatJsonForEasyuiDataGridDateTime(resultCount, result);

        }
        /// <summary>
        ///     日志实体
        /// </summary>
        /// <param name="keyValue">主键值</param>
        /// <returns></returns>
        public static MBaseLog GetEntity(int keyValue)
        {
            using (var conn = DbContext.Open())
            {
                return conn.QueryFirstOrDefault<MBaseLog>("select id=@id", new { id = keyValue });
            }

        }

        #endregion

        #region 提交数据

        /// <summary>
        ///     清空日志
        /// </summary>
        /// <param name="keepTime">保留时间段内</param>
        public static string RemoveLog(int keepTime)
        {
            DateTime operateTime;
            var result = new JsonMessage();
            switch (keepTime)
            {
                case 7:
                    operateTime = DateTime.Now.AddDays(-7);
                    break;
                case 30:
                    operateTime = DateTime.Now.AddMonths(-1);
                    break;
                case 90:
                    operateTime = DateTime.Now.AddMonths(-3);
                    break;
                default:
                    operateTime = DateTime.Now;
                    break;

            }
            using (var conn = DbContext.Open())
            {
                var ok = conn.Execute("delete from Base_Log where OperateTime<=@OperateTime", new { operateTime }) >= 0;
                result.Message = ok ? "删除成功。" : "删除失败。";
                result.Title = ok ? "1" : "0";
            }





            return result.ToString();

        }

        /// <summary>
        ///     写日志
        /// </summary>
        /// <param name="logEntity">对象</param>
        public static void WriteLog(MBaseLog logEntity)
        {
            logEntity.OperateTime = DateTime.Now;
            logEntity.DeleteMark = false;
            logEntity.IpAddress = Net.Ip;
            logEntity.IpAddressName = IpLocation.GetLocation(Net.Ip); ;
            logEntity.Browser = Net.Browser;
            using (var conn = DbContext.Open())
            {
                conn.Execute(@"INSERT INTO Base_Log
        (OperateTime,OperateAccount,OperateTypeId,OperateType,IPAddress,IPAddressName,Browser,ExecuteResult,ExecuteResultJson,DeleteMark)
    VALUES
        (@OperateTime,@OperateAccount,@OperateTypeId,@OperateType,@IPAddress,@IPAddressName,@Browser,@ExecuteResult,@ExecuteResultJson,@DeleteMark)", logEntity);
            }

        }

        #endregion
    }
}