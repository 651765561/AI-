﻿using System.Collections.Generic;
using System.Linq;
using Dapper;
using Ucfar.Application.Entity.SystemManage;
using Ucfar.Util;

namespace Ucfar.Application.Service.SystemManage
{
    public class ButtonService
    {
        public static List<MBaseButton> GetAll()
        {
            using (var conn = DbContext.Open())
            {
                var result = conn.Query<MBaseButton>(@"SELECT * FROM Base_Button order by SortCode").ToList();
                return result;
            }

        }
        /// <summary>
        /// 获取所有操作按钮
        /// </summary>
        /// <returns></returns>
        public static string GetAllButtons()
        {
            return GetAll().ToJson();
        }
        public static List<MBaseButton> GetButtonByMenuCode(string menuCode)
        {
            using (var conn = DbContext.Open())
            {
                var result = conn.Query<MBaseButton>(@"SELECT a.*,b.ButtonCode,b.MenuCode FROM Base_button a join Base_MenuButtonMap b on a.ButtonCode=b.ButtonCode WHERE b.menuCode = @menuCode order by a.SortCode ", new { menuCode }).ToList();
                return result;
            }

        }
        public static string AddButton(MBaseButton entity)
        {
            var result = new JsonMessage();
            if (HasButton(entity))
            {
                result.Message = "按钮名称或编码已存在！";
                result.Title = "0";
            }
            else
            {
                bool ok = Insert(entity);
                result.Message = ok ? "添加成功。" : "添加失败。";
                result.Title = ok ? "1" : "0";

            }

            return result.ToString();
        }
        public static string EditButton(MBaseButton entity)
        {
            var result = new JsonMessage();
            bool ok = Update(entity);
            result.Message = ok ? "修改成功。" : "修改失败。";
            result.Title = ok ? "1" : "0";
            return result.ToString();
        }
        public static string DelButton(int btnId)
        {
            var result = new JsonMessage();
            bool ok = Delete(btnId);
            result.Message = ok ? "删除成功。" : "删除失败。";
            result.Title = ok ? "1" : "0";
            return result.ToString();
        }
        private static bool Delete(int id)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"Delete from Base_Button where ID=@ID", new { ID = id });
                return a > 0;
            }
        }
        private static bool Update(MBaseButton model)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"UPDATE Base_Button SET ButtonCode=@ButtonCode,ButtonName=@ButtonName,SortCode=@SortCode,Description=@Description,ButtonIcon=@ButtonIcon  WHERE ID=@ID",
        new { model.ButtonCode, model.ButtonName, model.SortCode, model.Description, model.ButtonIcon, model.ID });
                return a > 0;

            }
        }
        private static bool Insert(MBaseButton model)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"INSERT INTO Base_Button
        (ButtonCode,ButtonName,SortCode,Description,ButtonIcon)VALUES
        (@ButtonCode,@ButtonName,@SortCode,@Description,@ButtonIcon)",
        new { model.ButtonCode, model.ButtonName, model.SortCode, model.Description, model.ButtonIcon });
                return a > 0;
            }
        }
        /// 判断按钮是否存在
        /// <param name="entity"></param>
        /// <returns></returns>
        private static bool HasButton(MBaseButton entity)
        {
            var btns = GetAll();
            return btns.Any(n => (n.ButtonCode == entity.ButtonCode || n.ButtonName == entity.ButtonName));
        }
        /// <summary>
        /// 根据角色集合与菜单代码获取工具栏集合
        /// </summary>
        /// <param name="roleCode"></param>
        /// <param name="menuCode"></param>
        /// <returns></returns>
        public static List<MBaseButton> GetButtonByRoleCodeMenuCode(List<string> roleCode, string menuCode)
        {
            using (var conn = DbContext.Open())
            {
                var result = conn.Query<MBaseButton>(@"select DISTINCT a.*,b.ButtonCode,b.MenuCode from Base_button a join Base_RoleMenuButtonMap b on a.ButtonCode=b.ButtonCode where b.roleCode in @roleCode and b.menuCode=@menuCode order by a.SortCode", new { roleCode, menuCode }).ToList();
                return result;
            }

        }
        public static string JsonDataForEasyUIdataGrid(int pageindex = 1, int pagesize = 1, string sort = "Id", string order = "asc", string filterJson = "")
        {

            var builder = new SqlBuilder();
            var query = builder.AddTemplate("SELECT * FROM Base_button /**where**/ /**orderby**/" +
                                "OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY", new { skip = (pageindex - 1) * pagesize, take = pagesize });
            var count = builder.AddTemplate("SELECT Count(*) FROM Base_button /**where**/");

            if (!string.IsNullOrEmpty(filterJson))
            {
                List<dynamic> filterList = filterJson.ToList<dynamic>();

                foreach (dynamic f in filterList)
                {
                    string sql = f.field + "='" + f.data + "'";
                    builder.Where(sql);
                }


            }
            if (!string.IsNullOrEmpty(sort) && !string.IsNullOrEmpty(order))
            {
                builder.OrderBy(sort + " " + order);
            }
            else
            {
                builder.OrderBy("SortCode asc");
            }

            List<MBaseButton> result;
            int resultCount;
            using (var conn = DbContext.Open())
            {
                result = conn.Query<MBaseButton>(query.RawSql, query.Parameters).ToList();
                resultCount = conn.ExecuteScalar<int>(count.RawSql, count.Parameters);
            }

            return Json.FormatJsonForEasyuiDataGrid(resultCount, result);

        }
        /// <summary>
        /// 获取菜单中的按钮列表
        /// </summary>
        /// <param name="menuCode">菜单编码</param>
        /// <returns></returns>
        public static IEnumerable<MBaseButton> GetButtonsBy(string menuCode)
        {
            const string sql = "select b.* from Base_MenuButtonMap a join Base_Button b on a.ButtonCode=b.ButtonCode where a.MenuCode=@menuCode order by b.SortCode";
            using (var conn = DbContext.Open())
            {
                var result = conn.Query<MBaseButton>(sql, new { menuCode }).ToList();
                return result;
            }
        }
        public static int DeleteNavButtons(string menuCode)
        {
            const string deleteSql = "delete Base_MenuButtonMap where menuCode=@menuCode";
            using (var conn = DbContext.Open())
            {
                var result = conn.Execute(deleteSql, new { menuCode });
                return result;
            }

        }
        public static int Insert(List<MBaseMenuButtonMap> models)
        {
            //const string sql = "INSERT INTO Base_MenuButtonMap (MenuCode,ButtonCode) VALUES (@MenuCode,@ButtonCode)";
            //return DbHelper.InsertMultiple(sql, models);
            using (var conn = DbContext.Open())
            {
                return conn.Execute(@"INSERT Base_MenuButtonMap (MenuCode,ButtonCode) VALUES (@MenuCode,@ButtonCode)", models);
            }
        }
        /// <summary>
        /// 根据菜单代码、角色代码获取按钮列表
        /// </summary>
        /// <param name="menuCode"></param>
        /// <param name="roleCode"></param>
        /// <returns></returns>
        public static string GetBtnsByMenuCode_RoleCode(string menuCode, string roleCode)
        {
            if (menuCode == "0")
            {
                return string.Empty;
            }
            List<MBaseButton> result;
            const string sql = "select b.* from Base_MenuButtonMap a join Base_Button b on a.ButtonCode=b.ButtonCode where a.MenuCode=@menuCode order by b.SortCode";
            using (var conn = DbContext.Open())
            {
                result = conn.Query<MBaseButton>(sql, new { menuCode }).ToList();
            }
            var menus = result.Select(n => new
            {
                n.ID,
                n.ButtonCode,
                n.ButtonIcon,
                n.ButtonName,
                n.SortCode,
                n.Description,
                @checked = GetButtonCodeByMenuCode_RoleCode(menuCode, roleCode).Any(a => a.Contains(n.ButtonCode))
            });
            return menus.ToJson();
        }
        /// <summary>
        /// 根据菜单代码及角色代码获取按钮代码集合
        /// </summary>
        /// <param name="menuCode"></param>
        /// <param name="roleCode"></param>
        /// <returns></returns>
        public static List<string> GetButtonCodeByMenuCode_RoleCode(string menuCode, string roleCode)
        {
            using (var conn = DbContext.Open())
            {
                var result =
                    conn.Query<string>(@"SELECT  ButtonCode FROM Base_RoleMenuButtonMap WHERE RoleCode = @roleCode and MenuCode=@menuCode",
                        new { roleCode, menuCode }).ToList();
                return result;
            }
        }
        //SaveRoleMenuButton
        public static string SetRoleMenuButton(string menuCode, string buttonCodes, string roleCode)
        {
            var result = new JsonMessage();
            if (string.IsNullOrEmpty(menuCode))
            {
                result.Message = "请选择要设置的菜单！";
                result.Title = "0";
            }
            if (string.IsNullOrEmpty(roleCode))
            {
                result.Message = "请选择要设置的角色！";
                result.Title = "0";
            }
            
            if (string.IsNullOrEmpty(buttonCodes))
            {
                var ok = DeleteRoleMenuButtonMap(menuCode, roleCode);
                result.Message = ok ? "设置为无任何操作权限成功。" : "操作失败。";
                result.Title = ok ? "1" : "0";
            }
            else
            {
                var models = new List<MBaseRoleMenuButtonMap>();
                var buttonCodeArr = buttonCodes.Split(',');
                foreach (var i in buttonCodeArr)
                {
                    var model = new MBaseRoleMenuButtonMap
                    {
                        ButtonCode = i,
                        MenuCode = menuCode,
                        RoleCode = roleCode
                    };
                    models.Add(model);
                }
                DeleteRoleMenuButtonMap(menuCode, roleCode);
                var ok=InsertRoleMenuButton(models);
                result.Message = ok ? "设置操作权限成功。" : "操作失败。";
                result.Title = ok ? "1" : "0";

            }

            return result.ToString();


        }
        private static bool DeleteRoleMenuButtonMap(string menuCode, string roleCode)
        {
            using (var conn = DbContext.Open())
            {
                return conn.Execute(@"Delete from Base_RoleMenuButtonMap where roleCode=@roleCode and  menuCode=@menuCode", new { roleCode, menuCode }) > 0;
            }
        }
        private static bool InsertRoleMenuButton(List<MBaseRoleMenuButtonMap> models)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"INSERT  Base_RoleMenuButtonMap (RoleCode,MenuCode,ButtonCode) VALUES (@RoleCode,@MenuCode,@ButtonCode)",models);
                return a > 0;
            }
        }

    }
}
