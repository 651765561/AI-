﻿using System;
using System.Web;
using Ucfar.Application.Entity.SystemManage;
using Ucfar.Util;

namespace Ucfar.Application.Service.SystemManage
{
    public class SysVisitor
    {
        public static SysVisitor Instance => Singleton<SysVisitor>.Instance;

        #region CookieName Key

        public const string CookieName = "UCFAR_COOKIE-NAME";
        public const string CookieUserNameKey = "UCFAR_USERNAME";
        public const string CoookieIsAdminKey = "UCFAR_ISADMIN";
        public const string CookieIsEnabledKey = "UCFAR_ISENABLED";
        public const string CookieConfigJson = "UCFAR_CONFIGJSON";
        public const string CookieRealNameKey = "UCFAR_REALNAME";
        public const string CookieMobileKey = "UCFAR_MOBILE";
        public const string CookieTelKey = "UCFAR_Tel";
        #endregion

        /// <summary>
        /// 用户是否禁用
        /// </summary>
        public bool IsDisabled => Convert.ToBoolean(CookieHelper.GetCookie(CookieName, CookieIsEnabledKey));

        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName => CookieHelper.GetCookie(CookieName, CookieUserNameKey);
        public string RealNameAll => CookieHelper.GetCookie(CookieRealNameKey);
        public string Mobile => CookieHelper.GetCookie(CookieMobileKey);
        public string Tel => CookieHelper.GetCookie(CookieTelKey);
        /// <summary>
        /// 是否超级管理员
        /// </summary>
        public bool IsAdmin => Convert.ToBoolean(CookieHelper.GetCookie(CookieName, CoookieIsAdminKey));

        public bool IsGuest => !CookieHelper.HasCookie(CookieName);

        public string ConfigJson => CookieHelper.GetCookie(CookieConfigJson);
        /// <summary>
        /// 皮肤名称
        /// </summary>
        public string ThemeName
        {
            get
            {
                if (string.IsNullOrEmpty(ConfigJson))
                    return "default";
                return ConfigJson.ToObject<ConfigModel>().Theme.Name;
            }
        }
        public bool LoginOut()
        {
            CookieHelper.DeleteCookie(CookieName);
            CookieHelper.DeleteCookie(CookieRealNameKey);
            CookieHelper.DeleteCookie(CookieMobileKey);
            CookieHelper.DeleteCookie(CookieTelKey);
            CookieHelper.DeleteCookie(CookieConfigJson);
            return true;

        }

    }
}
