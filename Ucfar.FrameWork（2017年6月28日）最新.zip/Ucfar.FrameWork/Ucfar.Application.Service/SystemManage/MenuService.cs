﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using Ucfar.Application.Entity.SystemManage;
using Ucfar.Util;

namespace Ucfar.Application.Service.SystemManage
{
    public class MenuService
    {
        public static List<MBaseMenu> GetAll()
        {
            using (var conn = DbContext.Open())
            {
                var result = conn.Query<MBaseMenu>(@"SELECT * FROM Base_Menu").ToList();
                return result;
            }

        }

        /// <summary>
        /// 根据角色代码集合获取菜单代码集合
        /// </summary>
        /// <param name="roleCode"></param>
        /// <returns></returns>
        public static List<string> GetMenuCodesByRoleCode(List<string> roleCode)
        {
            using (var conn = DbContext.Open())
            {
                var result =
                    conn.Query<string>(@"SELECT DISTINCT MenuCode FROM Base_RoleMenuMap WHERE RoleCode IN @roleCode",
                        new { roleCode }).ToList();
                return result;
            }

        }
        public static List<string> GetMenuCodesByRoleCode(string roleCode)
        {
            using (var conn = DbContext.Open())
            {
                var result =
                    conn.Query<string>(@"SELECT  MenuCode FROM Base_RoleMenuMap WHERE RoleCode = @roleCode",
                        new { roleCode }).ToList();
                return result;
            }

        }
        /// <summary>
        /// 根据菜单代码获取菜单实体集合
        /// </summary>
        /// <param name="menuCode"></param>
        /// <returns></returns>
        public static List<MBaseMenu> GetMenuByMenuCode(List<string> menuCode)
        {
            using (var conn = DbContext.Open())
            {
                var result =
                    conn.Query<MBaseMenu>(@"SELECT * FROM Base_Menu WHERE menuCode IN @menuCode", new { menuCode })
                        .ToList();
                return result;
            }

        }

        public static string BuildNavTreeJson()
        {
            return GetList(GetAll(), "0").ToList().ToJson();
        }

        private static IEnumerable<dynamic> GetList(List<MBaseMenu> navs, string parentCode)
        {
            var menus =
                navs.Where(n => n.ParentCode == parentCode)
                    .OrderBy(n => n.SortCode)
                    .Select(n => new
                    {
                        n.ID,
                        n.MenuName,
                        iconCls = n.IconClass,
                        n.URL,
                        n.MenuCode,
                        n.ParentCode,
                        n.SortCode,
                        n.IsVisible,
                        Buttons = ButtonService.GetButtonsBy(n.MenuCode),
                        children = GetList(navs, n.MenuCode)
                    });
            return menus;
        }

        public static string DeleteNav(string navids)
        {
            //var oldNavList = from n in GetAll().ToList()
            //                 where navids.Split(',').Contains(n.ID.ToString())
            //                 select n;
            List<string> ids = navids.Split(',').Distinct().ToList();
            var result = new JsonMessage();

            bool ok = Delete(ids);
            result.Message = ok ? "删除成功。" : "删除失败。";
            result.Title = ok ? "1" : "0";


            return result.ToString();
        }

        private static bool Delete(List<string> ids)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"Delete from Base_Menu where ID in @ID", new { ID = ids });
                return a > 0;
            }
        }

        public static string AddNav(MBaseMenu entity)
        {
            var result = new JsonMessage();
            if (HasNav(entity))
            {
                result.Message = "菜单名称或编码已存在！";
                result.Title = "0";
            }
            else
            {
                bool ok = Insert(entity);
                result.Message = ok ? "添加成功。" : "添加失败。";
                result.Title = ok ? "1" : "0";

            }

            return result.ToString();
        }

        public static bool Insert(MBaseMenu model)
        {
            using (var conn = DbContext.Open())
            {

                var a = conn.Execute(@"INSERT INTO Base_Menu
        (MenuCode,ParentCode,MenuName,URL,IconClass,SortCode,IsVisible)
    VALUES
        (@MenuCode,@ParentCode,@MenuName,@URL,@IconClass,@SortCode,@IsVisible)",
                    new
                    {
                        model.MenuCode,
                        model.ParentCode,
                        model.MenuName,
                        model.URL,
                        model.IconClass,
                        model.SortCode,
                        model.IsVisible
                    });
                return a > 0;
            }
        }

        public static string EditNav(MBaseMenu nav)
        {
            var result = new JsonMessage();

            bool ok = Update(nav);
            result.Message = ok ? "修改成功。" : "修改失败。";
            result.Title = ok ? "1" : "0";


            return result.ToString();

        }

        public static bool Update(MBaseMenu model)
        {
            using (var conn = DbContext.Open())
            {
                var a =
                    conn.Execute(
                        @"UPDATE Base_Menu SET MenuCode=@MenuCode,ParentCode=@ParentCode,MenuName=@MenuName,URL=@URL,IconClass=@IconClass,SortCode=@SortCode,IsVisible=@IsVisible  WHERE ID=@ID",
                        new
                        {
                            model.MenuCode,
                            model.ParentCode,
                            model.MenuName,
                            model.URL,
                            model.IconClass,
                            model.SortCode,
                            model.IsVisible,
                            model.ID
                        });
                return a > 0;

            }
        }

        /// <summary>
        /// 是否存在同名的导航菜单
        /// </summary>
        /// <returns></returns>
        public static bool HasNav(MBaseMenu entity)
        {
            var btns = GetAll();
            return btns.Any(n => (n.MenuName == entity.MenuName || n.MenuCode == entity.MenuCode));
        }

        /// <summary>
        /// 设置菜单按钮
        /// </summary>
        /// <param name="menuCode">菜单ID</param>
        /// <param name="buttonCodes">按钮</param>
        /// <returns></returns>
        public static string SetNavButtons(string menuCode, string buttonCodes)
        {
            var result = new JsonMessage();
            var models = new List<MBaseMenuButtonMap>();
            if ( !string.IsNullOrEmpty(menuCode))
            {
                if (string.IsNullOrEmpty(buttonCodes))
                {
                    ButtonService.DeleteNavButtons(menuCode);
                }
                else
                {
                    var arr = buttonCodes.Split(',');

                    foreach (var i in arr)
                    {
                        MBaseMenuButtonMap model = new MBaseMenuButtonMap
                        {
                            MenuCode = menuCode,
                            ButtonCode = i
                        };
                        models.Add(model);
                    }
                    ButtonService.DeleteNavButtons(menuCode);
                    ButtonService.Insert(models);
                    
                }
                result.Title = "1";
                result.Message = "菜单按钮设置成功";
            }
            else
            {
                result.Title = "0";
                result.Message = "菜单ID未找到";
            }
            return result.ToString();
        }

        public static string SaveRoleMenu(string roleCode, string menuCodes)
        {
            var result = new JsonMessage();
            var models = new List<MBaseRoleMenuMap>();
            if (!string.IsNullOrEmpty(roleCode) && !string.IsNullOrEmpty(menuCodes))
            {
                var arr = menuCodes.Split(',');

                foreach (var i in arr)
                {
                    var model = new MBaseRoleMenuMap
                    {
                        MenuCode = i,
                        RoleCode = roleCode
                    };
                    models.Add(model);
                }
                DeleteRoleMenu(roleCode);
                InsertRoleMenu(models);
                result.Title = "1";
                result.Message = "菜单权限设置成功";
            }
            else
            {
                result.Title = "0";
                result.Message = "权限代码为空或菜单代码未选择！";
            }
            return result.ToString();
        }

        private static void DeleteRoleMenu(string roleCode)
        {
            using (var conn = DbContext.Open())
            {
                conn.Execute(@"Delete from Base_RoleMenuMap where roleCode=@roleCode", new { roleCode });
            }
        }

        private static void InsertRoleMenu(List<MBaseRoleMenuMap> models)
        {
            using (var conn = DbContext.Open())
            {
                conn.Execute(@"INSERT  Base_RoleMenuMap
        (RoleCode,MenuCode)
    VALUES
        (@RoleCode,@MenuCode)", models);
            }
        }
    }
}
