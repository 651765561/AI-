﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using Ucfar.Application.Entity.SystemManage;
using Ucfar.Util;
using Ucfar.Util.Security;

namespace Ucfar.Application.Service.SystemManage
{
    public class UserService
    {
        /// <summary>
        /// 根据用户名获取用户的导航菜单
        /// </summary>
        /// <param name="userName">用户名</param>
        /// <param name="isAdmin"></param>
        /// <returns></returns>
        public static string GetNavJson(string userName, bool isAdmin)
        {
            var navList = GetMenusBy(userName, isAdmin);
            return navList.Any() ? BuildMenuJson(navList, "0").ToJson() : "";
        }
        public static string GetNavJsonByRoleCode(string roleCode)
        {
            var navList = MenuService.GetAll();
            return navList.Any() ? BuildMenuJsonByRoleCode(navList, "0", roleCode).ToJson() : "";
        }

        #region 获取指定用户拥有的导航菜单

        /// <summary>
        /// 获取指定用户拥有的导航菜单
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="isAdmin"></param>
        /// <returns></returns>
        public static List<MBaseMenu> GetMenusBy(string userName, bool isAdmin)
        {
            var allNavs = MenuService.GetAll();

            if (isAdmin && userName=="system") //如果是超管则返回所有导航菜单
                return allNavs;

            //用户拥有的角色代码集合
            var roleCode = RoleService.GetRolesBy(userName);
            //角色拥有的菜单代码集合
            var menuCode = MenuService.GetMenuCodesByRoleCode(roleCode);
            //菜单集合
            List<MBaseMenu> baseMenuList = MenuService.GetMenuByMenuCode(menuCode);
            return baseMenuList;
        }
        /// <summary>
        /// 根据角色代码返回菜单代码集合
        /// </summary>
        /// <param name="roleCode"></param>
        /// <returns></returns>
        public static List<string> GetMenuCodeByRoleCode(string roleCode)
        {
            return MenuService.GetMenuCodesByRoleCode(roleCode);

        }
        #endregion
        /// <summary>
        /// 生成菜单Json
        /// </summary>
        /// <param name="navs"></param>
        /// <param name="parentCode"></param>
        /// <returns></returns>
        private static IEnumerable<dynamic> BuildMenuJson(List<MBaseMenu> navs, string parentCode)
        {
            var menus =
                navs.Where(n => n.ParentCode == parentCode && n.IsVisible)
                           .OrderBy(n => n.SortCode)
                           .Select(n => new
                           {
                               id = n.ID,
                               text = n.MenuName,
                               iconCls = n.IconClass,
                               attributes = new
                               {
                                   url = n.URL,
                                   menuCode = n.MenuCode,
                                   parentCode = n.ParentCode,
                                   sortCode = n.SortCode
                               },
                               state =
                                            parentCode == "0"
                                                ? "open"
                                                : (navs.Any(a => a.ParentCode == n.MenuCode) ? "closed" : "open"),

                               children = BuildMenuJson(navs, n.MenuCode)
                           });
            return menus;
        }

        /// <summary>
        /// 根据角色代码生成菜单Json
        /// </summary>
        /// <param name="navs"></param>
        /// <param name="parentCode"></param>
        /// <param name="roleCode"></param>
        /// <returns></returns>
        private static IEnumerable<dynamic> BuildMenuJsonByRoleCode(List<MBaseMenu> navs, string parentCode, string roleCode)
        {
            var menus =
                navs.Where(n => n.ParentCode == parentCode && n.IsVisible)
                           .OrderBy(n => n.SortCode)
                           .Select(n => new
                           {
                               text = n.MenuName,
                               iconCls = n.IconClass,
                               attributes = new
                               {
                                   menuCode = n.MenuCode,
                                   sortCode = n.SortCode
                               },
                               @checked =
                               parentCode == "0"
                                                ? false
                                                : (!navs.Any(a => a.ParentCode == n.MenuCode) && GetMenuCodeByRoleCode(roleCode).Any(s => s.Contains(n.MenuCode))),

                               state =
                                            parentCode == "0"
                                                ? "open"
                                                : (navs.Any(a => a.ParentCode == n.MenuCode) ? "closed" : "open"),

                               children = BuildMenuJsonByRoleCode(navs, n.MenuCode, roleCode)
                           });
            return menus;
        }

        /// <summary>
        /// 创建指定功能页面的按钮
        /// </summary>
        /// <param name="userCode"></param>
        /// <param name="menuCode">菜单Id</param>
        /// <param name="isAdmin"></param>
        /// <returns></returns>
        public static string PageButtons(string userCode, string menuCode, bool isAdmin)
        {
            List<MBaseButton> btns = GetPageButtons(userCode, menuCode, isAdmin);
            // const string splitTag = @"<div class='datagrid-btn-separator'></div>";
            if (btns.Any())
            {
                List<string> btnHtmlArr = new List<string>();
                //foreach (var btn in btns.Where(a => a.ButtonCode != "browse")) //隐藏浏览按钮
                foreach (var btn in btns)
                {
                    var btnHtml = "<a id='" + btn.ButtonCode + "' style=' href='javascript:; ' plain='true' class='easyui-linkbutton' icon='" + btn.ButtonIcon + "' title='" + btn.ButtonName + "'>" + btn.ButtonName + "</a>";
                    btnHtmlArr.Add(btnHtml);
                }

                return string.Join("", btnHtmlArr);
            }
            return "";
        }
        public static List<MBaseButton> GetPageButtons(string userCode, string menuCode, bool isAdmin)
        {
            var buttons = isAdmin ? ButtonService.GetButtonByMenuCode(menuCode) : GetButtonByUserCodeMenuCode(userCode, menuCode);
            return buttons;
        }
        /// <summary>
        /// 根据用户名获取菜单工具栏列表
        /// </summary>
        /// <param name="userCode"></param>
        /// <param name="menuCode"></param>
        /// <returns></returns>
        private static List<MBaseButton> GetButtonByUserCodeMenuCode(string userCode, string menuCode)
        {
            var roles = RoleService.GetRolesBy(userCode);
            return ButtonService.GetButtonByRoleCodeMenuCode(roles, menuCode);


        }

        public static string JsonDataForEasyUIdataGrid(int pageindex = 1, int pagesize = 1, string sort = "Id", string order = "asc", string filterJson = "")
        {

            var builder = new SqlBuilder();
            var query = builder.AddTemplate("SELECT a.ID,a.UserCode,a.IsAdmin,a.RealName,a.Mobile,a.Telephone,a.SortCode,a.IsEnable,a.CreateDate,b.OrganizeName,a.OrganizeCode  FROM Base_User a join Base_Organize b on a.OrganizeCode=b.OrganizeCode /**where**/ /**orderby**/" +
                                "OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY", new { skip = (pageindex - 1) * pagesize, take = pagesize });
            var count = builder.AddTemplate("SELECT Count(*) FROM Base_User a join Base_Organize b on a.OrganizeCode=b.OrganizeCode /**where**/");
            builder.Where("a.UserCode!='system'");
            if (!string.IsNullOrEmpty(filterJson))
            {
                dynamic filter = filterJson.ToJObject();
                string sql = "a.OrganizeCode in(" + filter.data + ")";
                builder.Where(sql);

            }
            if (!string.IsNullOrEmpty(sort) && !string.IsNullOrEmpty(order))
            {
                builder.OrderBy("a." + sort + " " + order);
            }
            else
            {
                builder.OrderBy("a.SortCode asc");
            }

            List<dynamic> result;
            int resultCount;
            using (var conn = DbContext.Open())
            {
                result = conn.Query<dynamic>(query.RawSql, query.Parameters).ToList();
                resultCount = conn.ExecuteScalar<int>(count.RawSql, count.Parameters);
            }

            return Json.FormatJsonForEasyuiDataGrid(resultCount, result);

        }
        #region CRUD

        public static List<MBaseUser> GetAll()
        {
            using (var conn = DbContext.Open())
            {
                var result = conn.Query<MBaseUser>(@"SELECT * FROM Base_User").ToList();
                return result;
            }
        }

        public static string AddUser(MBaseUser u, string roleIds)
        {
            var result = new JsonMessage();
            if (HasUserName(u.UserCode))
            {
                result.Message = "用户名已存在！";
                result.Title = "0";
            }
            else
            {
                u.Password = DesEncrypt.Encrypt(u.Password, "UcfarDES");
                bool ok = Insert(u);

                if (!string.IsNullOrEmpty(roleIds))
                {
                    var roleIdArr = roleIds.Split(',');
                    var modeList = new List<MBaseUserRoleMap>();
                    MBaseUserRoleMap list = new MBaseUserRoleMap();
                    foreach (var roleCode in roleIdArr)
                    {
                        list.UserCode = u.UserCode;
                        list.RoleCode = roleCode;
                        modeList.Add(list);
                    }

                    InsertUserRole(modeList);
                }
                result.Message = ok ? "添加成功。" : "添加失败。";
                result.Title = ok ? "1" : "0";

            }

            return result.ToString();


        }
        public static bool HasUserName(string username)
        {
            var userNames = GetAll();
            return userNames.Any(n => (n.UserCode == username));
        }
        private static bool Insert(MBaseUser model)
        {
            using (var conn = DbContext.Open())
            {

                var a = conn.Execute(@"INSERT INTO Base_User
        (UserCode,Password,IsAdmin,RealName,Mobile,Telephone,SortCode,IsEnable,CreateDate,OrganizeCode)VALUES
        (@UserCode,@Password,@IsAdmin,@RealName,@Mobile,@Telephone,@SortCode,@IsEnable,@CreateDate,@OrganizeCode)",
        new { model.UserCode, model.Password, model.IsAdmin, model.RealName, model.HeadIcon, model.Mobile, model.Telephone, model.SortCode, model.IsEnable, CreateDate = DateTime.Now, model.OrganizeCode });
                return a > 0;
            }
        }

        private static void InsertUserRole(List<MBaseUserRoleMap> modelList)
        {
            using (var conn = DbContext.Open())
            {

                conn.Execute(@"INSERT  Base_UserRoleMap(UserCode,RoleCode) VALUES (@UserCode,@RoleCode)", modelList);

            }
        }

        public static string EditUser(MBaseUser u)
        {
            var result = new JsonMessage();
          
                bool ok = Update(u);
                result.Message = ok ? "修改成功。" : "修改失败。";
                result.Title = ok ? "1" : "0";
            
           
            return result.ToString();


        }
        
        private static bool Update(MBaseUser model)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"UPDATE Base_User SET UserCode=@UserCode,IsAdmin=@IsAdmin,RealName=@RealName,Mobile=@Mobile,Telephone=@Telephone,SortCode=@SortCode,IsEnable=@IsEnable,CreateDate=@CreateDate,OrganizeCode=@OrganizeCode  WHERE ID=@ID",
                new { model.UserCode, model.IsAdmin, model.RealName, model.Mobile, model.Telephone, model.SortCode, model.IsEnable, CreateDate = DateTime.Now, model.OrganizeCode, model.ID });
                return a > 0;
            }
        }
        public static string DeleteUser(int id)
        {
            var result = new JsonMessage();
            bool ok = Delete(id);
            result.Message = ok ? "删除成功。" : "删除失败。";
            result.Title = ok ? "1" : "0";
            return result.ToString();


        }
        private static bool Delete(int id)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"Delete from Base_User where ID=@ID", new { id});
                return a > 0;
            }
        }
        public static string EditPassword(int id,string newPassword)
        {
            var newMd5Pass = DesEncrypt.Encrypt(newPassword, "UcfarDES");
            var result = new JsonMessage();
            bool ok = UpdatePassword(id, newMd5Pass);
            result.Message = ok ? "密码修改成功。" : "密码修改失败。";
            result.Title = ok ? "1" : "0";
            return result.ToString();


        }
        private static bool UpdatePassword(int id, string newPassword)
        {
            using (var conn = DbContext.Open())
            {
                var result = conn.Execute(@"update Base_User set Password=@password where ID = @id", new { password=newPassword, id });
                return result>0;
            }
        }
        public static string IsEdit(int id,string field,bool fieldValue)
        {
            var result = new JsonMessage();
            bool ok = UpdateField(id,field,fieldValue);
            result.Message = ok ? "设置成功。" : "设置失败。";
            result.Title = ok ? "1" : "0";
            return result.ToString();


        }
        private static bool UpdateField(int id, string field, bool fieldValue)
        {
            var sql = string.Empty;
            DynamicParameters para = new DynamicParameters();
            if (field == "IsAdmin")
            {
                sql = @"update Base_User set IsAdmin=@IsAdmin where ID = @ID";
                para.Add("IsAdmin",fieldValue);
                para.Add("ID", id);
            }
            if (field == "IsEnable")
            {
                sql = @"update Base_User set IsEnable=@IsEnable where ID = @ID";
                para.Add("IsEnable", fieldValue);
                para.Add("ID", id);
            }
            using (var conn = DbContext.Open())
            {
                var result = conn.Execute(sql, para);
                return result > 0;
            }
        }
        #endregion

        public static string GetUsersByRoleCode(string roleCode)
        {
            List<MBaseUser> result = GetAll();
            var users = result.Select(n => new
            {
                n.UserCode,
                n.RealName,
                @checked = GetUserCodesByRoleCode(roleCode).Any(a => a==n.UserCode)
            });
            return users.Where(n => n.UserCode != "system").ToJson();
        }
        public static List<string> GetUserCodesByRoleCode(string roleCode)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Query<string>(@"select UserCode from Base_UserRoleMap where RoleCode=@RoleCode", new { roleCode }).ToList();
                return a;
            }
        }
    }
}
