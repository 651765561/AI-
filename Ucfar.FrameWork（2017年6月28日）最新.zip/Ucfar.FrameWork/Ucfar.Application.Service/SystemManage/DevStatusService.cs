﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using Ucfar.Application.Entity.SystemManage;
using Ucfar.Util;
using System.Configuration;
namespace Ucfar.Application.Service.SystemManage
{
   public class DevStatusService
    {
        string sqlConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        #region 自定义方法
        public DataTable GetListForLines()
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append(" select ROW_NUMBER() over(order by c.id) RowNumber,  c.id as crossingID, c.crsname,d.IsOnline,d.CreateDate from  tb_crossing as c , TB_DevStatus as d ");
            strSql.Append(" where c.crsCode=d.crscode ");
            return Tools.getDataSet(strSql.ToString(), sqlConnectionString).Tables[0];
        }
        public DataTable GetListForLines(DateTime startDate, DateTime endDate)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append(" select   ROW_NUMBER() over(order by c.id) RowNumber,  c.id as crossingID, c.crsname,d.IsOnline, ");
            strSql.Append(" CONVERT(varchar(100), d.CreateDate, 23) as CreateDate from  tb_crossing as c , TB_DevStatus as d  ");
            strSql.Append(" where c.crsCode=d.crscode  and CONVERT(varchar(100), d.CreateDate, 23)  between '" + startDate.ToString("yyyy-MM-dd") + "' and '" + endDate.ToString("yyyy-MM-dd") + "'  ");
            return Tools.getDataSet(strSql.ToString(), sqlConnectionString).Tables[0];
        }
        public DataTable GetPieChart(string startDate, string endDate)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append(" select  d.IsOnline ,count(d.IsOnline)  as IsOnlineNum  from  tb_crossing as c , TB_DevStatus as d  ");
            strSql.Append(" where c.crsCode=d.crscode ");

            if (startDate != "" && endDate != "")
            {
                strSql.Append(" and CONVERT(varchar(100), d.CreateDate, 23) between   '" + Convert.ToDateTime(startDate).ToString("yyyy-MM-dd") + "' and '" + Convert.ToDateTime(endDate).ToString("yyyy-MM-dd") + "' ");
            }
            strSql.Append(" group by d.IsOnline ");

            return Tools.getDataSet(strSql.ToString(), sqlConnectionString).Tables[0];
        }
        #endregion
        public static string JsonDataForEasyUIdataGrid(bool alarm,string userName, bool isAdmin=false,int pageindex = 1, int pagesize = 1, string sort = "Id", string order = "asc", string filterJson = "")
        {
          
            var builder = new SqlBuilder();
            var query = builder.AddTemplate("SELECT a.*,b.CrsName,b.CrsIp FROM TB_DevStatus a join TB_Crossing b on a.CrsCode=b.CrsCode /**where**/ /**orderby**/" +
                                "OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY", new { skip = (pageindex - 1) * pagesize, take = pagesize });
            var count = builder.AddTemplate("SELECT Count(*) FROM TB_DevStatus a join TB_Crossing b on a.CrsCode=b.CrsCode /**where**/");
            if (!isAdmin)
            {
                //用户拥有的角色代码集合
                var roleCode = RoleService.GetRolesBy(userName);
                //角色拥有的分布式服务编码集合
                var subCodes = SubServerService.GetSubCodeByRoleCodes(roleCode);
                builder.Where("a.SubCode in @SubCode",new { SubCode=subCodes });
            }
            if (alarm)
            {
                builder.Where("a.ESAlarm=@ESAlarm", new { ESAlarm=1 });
            }
            if (!string.IsNullOrEmpty(filterJson))
            {
                List<dynamic> filterList = filterJson.ToList<dynamic>();

                foreach (dynamic f in filterList)
                {
                    string sql = f.field + " like '%" + f.data + "%' ";
                    builder.Where(sql);
                }


            }
            if (!string.IsNullOrEmpty(sort) && !string.IsNullOrEmpty(order))
            {
                builder.OrderBy("a." + sort + " " + order);
            }
            else
            {
                builder.OrderBy("a.CrsCode asc");
            }

            List<dynamic> result;
            int resultCount;
            using (var conn = DbContext.Open())
            {
                result = conn.Query<dynamic>(query.RawSql, query.Parameters).ToList();
                resultCount = conn.ExecuteScalar<int>(count.RawSql, count.Parameters);
            }

            return Json.FormatJsonForEasyuiDataGridDateTime(resultCount, result);

        }
        public static string JsonDataForOffLine(string userName, bool isAdmin = false, int pageindex = 1, int pagesize = 20)
        {

            var builder = new SqlBuilder();
            var query = builder.AddTemplate("SELECT a.CrsCode,a.CreateDate,b.CrsName,b.CrsIp FROM TB_DevStatus a join TB_Crossing b on a.CrsCode=b.CrsCode /**where**/ /**orderby**/" +
                                "OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY", new { skip = (pageindex - 1) * pagesize, take = pagesize });
            var count = builder.AddTemplate("SELECT Count(*) FROM TB_DevStatus a join TB_Crossing b on a.CrsCode=b.CrsCode /**where**/");
            builder.Where("a.IsOnline = @IsOnline", new { IsOnline = false });
            if (!isAdmin)
            {
                //用户拥有的角色代码集合
                var roleCode = RoleService.GetRolesBy(userName);
                //角色拥有的分布式服务编码集合
                var subCodes = SubServerService.GetSubCodeByRoleCodes(roleCode);
                builder.Where("a.SubCode in @SubCode", new { SubCode = subCodes });
            }
            builder.OrderBy("a.CreateDate desc");
            List<dynamic> result;
            int resultCount;
            using (var conn = DbContext.Open())
            {
                result = conn.Query<dynamic>(query.RawSql, query.Parameters).ToList();
                resultCount = conn.ExecuteScalar<int>(count.RawSql, count.Parameters);
            }

            return Json.FormatJsonForEasyuiDataGridDateTime(resultCount, result);

        }

        public static dynamic GetAlarm(string userName, bool isAdmin = false)
        {
            using (var conn = DbContext.Open())
            {
                dynamic model;
                if (!isAdmin)
                {
                    //用户拥有的角色代码集合
                    var roleCode = RoleService.GetRolesBy(userName);
                    //角色拥有的分布式服务编码集合
                    var subCodes = SubServerService.GetSubCodeByRoleCodes(roleCode);
                    model = conn.Query<dynamic>(@"select top 1 a.ESAlarm,a.CreateDate,b.CrsName from TB_DevStatus a join TB_Crossing b on a.CrsCode=b.CrsCode where a.ESAlarm=1 and SubCode in @SubCode order by CreateDate desc ", new {subCodes}).FirstOrDefault();
                }
                else
                {
                    model = conn.Query<dynamic>(@"select top 1 a.ESAlarm,a.CreateDate,b.CrsName from TB_DevStatus a join TB_Crossing b on a.CrsCode=b.CrsCode  where a.ESAlarm=1 order by CreateDate desc ").FirstOrDefault();
                }
                return model;
            }
        }

        public static string JsonDataForPropertyGrid(string filterJson = "")
        {

            var builder = new SqlBuilder();
            var query = builder.AddTemplate("SELECT top 1 * FROM TB_DevStatus /**where**/ ");
           
            if (!string.IsNullOrEmpty(filterJson))
            {
                List<dynamic> filterList = filterJson.ToList<dynamic>();

                foreach (dynamic f in filterList)
                {
                    string sql = f.field + "= '" + f.data + "' ";
                    builder.Where(sql);
                }
            }

           // builder.Where("a.ESAlarm=@ESAlarm", new { ESAlarm = 1 });

            using (var conn = DbContext.Open())
            {
                MtbDevStatus result = conn.Query<MtbDevStatus>(query.RawSql, query.Parameters).FirstOrDefault();
                var infoArr = typeof(MtbDevStatus).GetProperties();
                List<ExpandoObject> list =new List<ExpandoObject>();
               
                foreach (var i in infoArr)
                {
                    dynamic info = new ExpandoObject();
                    switch (i.Name)
                    {
                        case "Camera_One":
                            info.name ="相机一";
                            info.value = i.GetValue(result).ToString();
                            info.group = "开关控制";
                            info.editor = new
                            {
                                type = "switchbutton",
                                options=new {
                                    on= "checked"
                                }
                            };
                            list.Add(info);
                           // info.editor.options = "switchbutton";
                            break;
                        case "Camera_Two":
                            info.name = "相机二";
                            info.value = i.GetValue(result).ToString();
                            info.group = "开关控制";
                            info.editor = new
                            {
                                type = "switchbutton",
                                options = new
                                {
                                    on = "checked"
                                }
                            };
                            list.Add(info);
                           
                            break;

                    }
                }
           
                 return list.ToJson();
            }

        }

        public static  string GetByCrsCode(string crsCode)
        {
            var sql = @"SELECT * from TB_DevStatus where CrsCode=@CrsCode";
            using (var cnn = DbContext.Open())
            {
                var result = cnn.QueryFirstOrDefault<MtbDevStatus>(sql,new {crsCode});
                return result.ToJson();
            }

        }
        public static bool Update(string crsCode,string cmd,string cmdValue)
        {
            using (var conn = DbContext.Open())
            {
                string sql = $"UPDATE TB_DevStatus SET {cmd} ='{cmdValue}' where CrsCode={crsCode}";
                var a = conn.Execute(sql);
                return a > 0;
            }
        }

    }
}
