﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using Ucfar.Application.Entity.Model;
using Ucfar.Util;

namespace Ucfar.Application.Service.SystemManage
{
    public class NewsService
    {
        public static string InsertNews(MBaseNews model)
        {
            var result = new JsonMessage();
            using (var conn = DbContext.Open())
            {

                var ok = conn.Execute(@"INSERT INTO Base_News
        (Title,Memo)
    VALUES
        (@Title,@Memo)",new { Title=model.Title, Memo=model.Memo+"[接收手机:"+model.Sjhm+"]"} );
                result.Message = ok >0? "添加成功。" : "添加失败。";
                result.Success = ok>0;
            }
            return result.ToString();
        }
        public static string EditNews(MBaseNews model)
        {
            var result = new JsonMessage();

            bool ok = Update(model);
            result.Message = ok ? "修改成功。" : "修改失败。";
            result.Success = ok;


            return result.ToString();


        }
        private static bool Update(MBaseNews model)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"UPDATE Base_News SET 
 Title=@Title,Memo=@Memo,CreateDate=@CreateDate  
 WHERE ID=@ID",
         new {  model.Title,  model.Memo, CreateDate=DateTime.Now, ID = model.Id });
                return a > 0;
            }
        }
        public static string DeleteNews(int id)
        {
            var result = new JsonMessage();
            bool ok = Delete(id);
            result.Message = ok ? "删除成功。" : "删除失败。";
            result.Title = ok ? "1" : "0";
            return result.ToString();


        }
        private static bool Delete(int id)
        {
            using (var conn = DbContext.Open())
            {
                var a = conn.Execute(@"Delete from Base_News where ID=@ID", new { ID = id });
                return a > 0;
            }
        }
        public static string JsonDataForEasyUIdataGrid(int pageindex = 1, int pagesize = 1, string sort = "Id", string order = "asc", string filterJson = "")
        {

            var builder = new SqlBuilder();
            var query = builder.AddTemplate("SELECT  * FROM Base_News /**where**/ /**orderby**/" +
                                "OFFSET @skip ROWS FETCH NEXT @take ROWS ONLY", new { skip = (pageindex - 1) * pagesize, take = pagesize });
            var count = builder.AddTemplate("SELECT Count(*) from Base_News /**where**/");

            if (!string.IsNullOrEmpty(filterJson))
            {
                List<dynamic> filterList = filterJson.ToList<dynamic>();

                foreach (dynamic f in filterList)
                {
                    string data = f.data;
                    if (!string.IsNullOrEmpty(data))
                    {
                        string sql = f.field + "='" + data.Trim() + "'";
                        builder.Where(sql);
                    }

                }


            }
            if (!string.IsNullOrEmpty(sort) && !string.IsNullOrEmpty(order))
            {
                builder.OrderBy(sort + " " + order);
            }
            else
            {
                builder.OrderBy("ID desc");
            }

            List<MBaseNews> result;
            int resultCount;
            using (var conn = DbContext.Open())
            {
                result = conn.Query<MBaseNews>(query.RawSql, query.Parameters).ToList();
                resultCount = conn.ExecuteScalar<int>(count.RawSql, count.Parameters);
            }

            return Json.FormatJsonForEasyuiDataGridDateTime(resultCount, result);

        }

    }
}
