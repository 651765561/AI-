﻿using System.Web.Optimization;
using System.Web.UI;

namespace Ucfar.Application.Web
{
    public class BundleConfig
    {
        // 有关绑定的详细信息，请访问 http://go.microsoft.com/fwlink/?LinkID=303951
        public static void RegisterBundles(BundleCollection bundles)
        {
            ResetIgnorePatterns(bundles.IgnoreList);
            //easyui css
            bundles.Add(new StyleBundle("~/bundles/UICss")
                .Include("~/Content/Css/icon.css", new CssRewriteUrlTransform())
                .Include("~/Content/css/base.css", new CssRewriteUrlTransform()));



            //easyui scripts
            bundles.Add(new ScriptBundle("~/bundles/UIJs").Include(
                             "~/Content/Easyui/jquery.min.js",
                            "~/Content/Easyui/jquery.easyui.min.js",
                            "~/Content/Easyui/locale/easyui-lang-zh_CN.js",
                            "~/Content/Scripts/core/Jquery.Ajax.js",
                            "~/Content/Scripts/core/jquery.cookie.js",
                            "~/Content/Scripts/core/easyUiExt.js",
                            "~/Content/Scripts/core/jqueryExt.js"
                          ));

            bundles.Add(new ScriptBundle("~/bundles/CoreJs").Include(
                //"~/Content/Scripts/core/utils.js",
                //"~/Content/Scripts/core/common.js",
                //"~/Content/Scripts/core/jquery.easyui.fix.js",
                "~/Content/Scripts/core/newlayout.js"));

        }
        public static void ResetIgnorePatterns(IgnoreList ignoreList)
        {
            ignoreList.Clear();
            ignoreList.Ignore("*.intellisense.js");
            ignoreList.Ignore("*-vsdoc.js");
            ignoreList.Ignore("*.debug.js", OptimizationMode.WhenEnabled);
            ignoreList.Ignore("*.min.js", OptimizationMode.WhenEnabled);
            ignoreList.Ignore("*.min.css", OptimizationMode.WhenEnabled);
        }
    }
}