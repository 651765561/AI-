﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Ucfar.Application.Service.SystemManage;
using Ucfar.Util;

namespace Ucfar.Application.Web.Modules.Handler
{
    /// <summary>
    /// Ctrl 的摘要说明
    /// </summary>
    public class Ctrl : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.AddHeader("Access-Control-Allow-Origin", "*");
            //context.Response.ContentType = "text/plain";
            context.Response.ContentType = "application/Json";
            string cameraOne = context.Request["Camera_One"] == "true" ? "true" : "false";
            string cameraTwo = context.Request["Camera_Two"] == "true" ? "true" : "false";
            string cameraThree = context.Request["Camera_Three"] == "true" ? "true" : "false";
            string router = context.Request["Router"] == "true" ? "true" : "false";
            string fan = context.Request["Fan"] == "true" ? "true" : "false";
            string acb = context.Request["Acb"] == "true" ? "true" : "false";
            string fot = context.Request["Fot"] == "true" ? "true" : "false";
            string switchOnSum = context.Request["SwitchOnSum"];
            string aliveTime = context.Request["AliveTime"];
            string switchInt = context.Request["SwitchInt"];
            string coolingTemp = context.Request["CoolingTemp"];
            string alarmTemp = context.Request["AlarmTemp"];
            string thresholdVoltage = context.Request["ThresholdVoltage"];
            string closeAlarm = context.Request["CloseAlarm"] == "true" ? "true" : "false";
            var crsCode = context.Request["crsCode"];
            var action = context.Request["action"];
            JsonMessage msg = new JsonMessage();
            if (action != null && !string.IsNullOrEmpty(crsCode))
            {

                switch (action)
                {
                    case "Camera_One":
                        if (!string.IsNullOrEmpty(cameraOne)) //相机一开||关
                        {
                            msg = Ctl.Instance.CameraOne(crsCode, cameraOne);

                        }
                        break;
                    case "Camera_Two":
                        if (!string.IsNullOrEmpty(cameraTwo)) //相机二开||关
                        {
                            msg = Ctl.Instance.CameraTwo(crsCode, cameraTwo);

                        }
                        break;
                    case "Camera_Three":
                        if (!string.IsNullOrEmpty(cameraThree)) //相机三开||关
                        {
                            msg = Ctl.Instance.CameraThree(crsCode, cameraThree);

                        }
                        break;
                    case "Fot":
                        if (!string.IsNullOrEmpty(fot)) //光端机重启
                        {
                            msg = Ctl.Instance.Fot(crsCode, fot);

                        }
                        break;
                    case "Router":
                        if (!string.IsNullOrEmpty(router)) //路由器重启
                        {
                            msg = Ctl.Instance.Router(crsCode, router);

                        }
                        break;
                    case "Fan":
                        if (!string.IsNullOrEmpty(fan)) //风扇开||关
                        {
                            msg = Ctl.Instance.Fan(crsCode, fan);

                        }
                        break;
                    case "Acb":
                        if (!string.IsNullOrEmpty(acb)) //空开开||关
                        {
                            msg = Ctl.Instance.Acb(crsCode, acb);

                        }
                        break;
                    case "AlarmTemp":
                        if (!string.IsNullOrEmpty(alarmTemp)) //设置报警温度
                        {
                            msg = Ctl.Instance.AlarmTemp(crsCode, alarmTemp);

                        }
                        break;
                    case "SwitchOnSum":
                        if (!string.IsNullOrEmpty(switchOnSum)) //设置空开合闸次数
                        {
                            msg = Ctl.Instance.SwitchOnSum(crsCode, switchOnSum);

                        }
                        break;
                    case "CloseAlarm":
                        if (!string.IsNullOrEmpty(closeAlarm)) //设置门禁报警
                        {
                            msg = Ctl.Instance.CloseAlarm(crsCode, closeAlarm);

                        }
                        break;
                    case "AliveTime":
                        if (!string.IsNullOrEmpty(aliveTime)) //设置通信链接时间
                        {
                            msg = Ctl.Instance.AliveTime(crsCode, aliveTime);

                        }
                        break;
                    case "SwitchInt":
                        if (!string.IsNullOrEmpty(switchInt)) //设置空开合闸间隔
                        {
                            msg = Ctl.Instance.SwitchInt(crsCode, switchInt);

                        }
                        break;
                    case "CoolingTemp":
                        if (!string.IsNullOrEmpty(coolingTemp)) //设置冷却温度
                        {
                            msg = Ctl.Instance.CoolingTemp(crsCode, coolingTemp);

                        }
                        break;
                    case "ThresholdVoltage":
                        if (!string.IsNullOrEmpty(thresholdVoltage)) //设置电池合闸门限电压
                        {
                            msg = Ctl.Instance.ThresholdVoltage(crsCode, thresholdVoltage);

                        }
                        break;
                }

            }
            else
            {
                msg = new JsonMessage { Title = "机箱编码参数不能为空", Message = "请检查参数是否正确", Success = false };
            }
            
            context.Response.Write(msg.ToJson());
           
           
        }

        public bool IsReusable => false;
    }
}