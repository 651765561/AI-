﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Ucfar.Application.Entity;
using Ucfar.Util.Security;


namespace NUnit.Test
{
    [TestFixture]
    public class Class1
    {
        [Test]
        public void NoOrderBy_Returns()
        {
            var system = DesEncrypt.Encrypt("7789606", "UcfarDES");
            var test = DesEncrypt.Encrypt("88888888", "UcfarDES");
           // Assert.IsEmpty(system);
            Assert.IsEmpty(test);
        }
    }
}
