﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Reflection;
using Ucfar.Util.Config;
namespace NUnit.Test
{
    public class DbContext
    {

        private static readonly string ConnectionString = Config.DefaultConnectionString;
        private  static SqlConnection _connection, _marsConnection;
        public static SqlConnection Connection => _connection ?? (_connection = GetOpenConnection());
        public static SqlConnection MarsConnection => _marsConnection ?? (_marsConnection = GetOpenConnection(true));

        public void Dispose()
        {
            Connection?.Dispose();
        }
        private static SqlConnection GetOpenConnection(bool mars = false)
        {
            var cs = ConnectionString;
            if (mars)
            {
                var scsb = new SqlConnectionStringBuilder(cs)
                {
                    MultipleActiveResultSets = true
                };
                cs = scsb.ConnectionString;
            }
            var connection = new SqlConnection(cs);
            connection.Open();
            return connection;
        }
 

    }
}
