﻿using System;

namespace Ucfar.Application.Entity
{
    /// <summary>
    /// 作者:yekin-yu
    /// 日期：2016/10/28 14:51:38
    /// </summary>
    public class PolicyListRb
    {
        /// <summary>
        ///  ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        ///  startDate1
        /// </summary>
        public DateTime StartDate1 { get; set; }

        /// <summary>
        ///  endDate1
        /// </summary>
        public DateTime EndDate1 { get; set; }

        /// <summary>
        ///  startDate2
        /// </summary>
        public DateTime StartDate2 { get; set; }

        /// <summary>
        ///  endDate2
        /// </summary>
        public DateTime EndDate2 { get; set; }

        /// <summary>
        ///  comCode
        /// </summary>
        public string ComCode { get; set; }

        /// <summary>
        ///  policyNo
        /// </summary>
        public string PolicyNo { get; set; }

        /// <summary>
        ///  sumPayTax
        /// </summary>
        public decimal SumPayTax { get; set; }

        /// <summary>
        ///  hphm
        /// </summary>
        public string Hphm { get; set; }

        /// <summary>
        ///  hpzl
        /// </summary>
        public string Hpzl { get; set; }

        /// <summary>
        ///  hpys
        /// </summary>
        public string Hpys { get; set; }

        /// <summary>
        ///  engineNo
        /// </summary>
        public string EngineNo { get; set; }

        /// <summary>
        ///  frameNo
        /// </summary>
        public string FrameNo { get; set; }

        /// <summary>
        ///  enrollDate
        /// </summary>
        public DateTime EnrollDate { get; set; }

        /// <summary>
        ///  modelCode
        /// </summary>
        public string ModelCode { get; set; }

        /// <summary>
        ///  brandName
        /// </summary>
        public string BrandName { get; set; }

        /// <summary>
        ///  purchasePrice
        /// </summary>
        public decimal? PurchasePrice { get; set; }

        /// <summary>
        ///  exhaustScale
        /// </summary>
        public string ExhaustScale { get; set; }

        /// <summary>
        ///  actualValue
        /// </summary>
        public decimal? ActualValue { get; set; }

        /// <summary>
        ///  insuredName
        /// </summary>
        public string InsuredName { get; set; }

        /// <summary>
        ///  identifyNumber
        /// </summary>
        public string IdentifyNumber { get; set; }

        /// <summary>
        ///  insuredAddress
        /// </summary>
        public string InsuredAddress { get; set; }

        /// <summary>
        ///  sumBenchPremium
        /// </summary>
        public decimal SumBenchPremium { get; set; }

        /// <summary>
        ///  discount
        /// </summary>
        public string Discount { get; set; }

        /// <summary>
        ///  sumPremium
        /// </summary>
        public decimal SumPremium { get; set; }

        /// <summary>
        ///  sumNetPremium
        /// </summary>
        public decimal SumNetPremium { get; set; }

        /// <summary>
        ///  sumTaxPremium
        /// </summary>
        public decimal SumTaxPremium { get; set; }

        /// <summary>
        ///  kindName01
        /// </summary>
        public string KindName01 { get; set; }

        /// <summary>
        ///  amount01
        /// </summary>
        public decimal Amount01 { get; set; }

        /// <summary>
        ///  benchMarkPremium01
        /// </summary>
        public decimal BenchMarkPremium01 { get; set; }

        /// <summary>
        ///  premium01
        /// </summary>
        public decimal Premium01 { get; set; }

        /// <summary>
        ///  kindName02
        /// </summary>
        public string KindName02 { get; set; }

        /// <summary>
        ///  amount02
        /// </summary>
        public decimal Amount02 { get; set; }

        /// <summary>
        ///  benchMarkPremium02
        /// </summary>
        public decimal BenchMarkPremium02 { get; set; }

        /// <summary>
        ///  premium02
        /// </summary>
        public decimal Premium02 { get; set; }

        /// <summary>
        ///  kindName03
        /// </summary>
        public string KindName03 { get; set; }

        /// <summary>
        ///  amount03
        /// </summary>
        public decimal Amount03 { get; set; }

        /// <summary>
        ///  benchMarkPremium03
        /// </summary>
        public decimal BenchMarkPremium03 { get; set; }

        /// <summary>
        ///  premium03
        /// </summary>
        public decimal Premium03 { get; set; }

        /// <summary>
        ///  kindName04
        /// </summary>
        public string KindName04 { get; set; }

        /// <summary>
        ///  amount04
        /// </summary>
        public decimal Amount04 { get; set; }

        /// <summary>
        ///  benchMarkPremium04
        /// </summary>
        public decimal BenchMarkPremium04 { get; set; }

        /// <summary>
        ///  premium04
        /// </summary>
        public decimal Premium04 { get; set; }

        /// <summary>
        ///  kindName05
        /// </summary>
        public string KindName05 { get; set; }

        /// <summary>
        ///  amount05
        /// </summary>
        public decimal Amount05 { get; set; }

        /// <summary>
        ///  benchMarkPremium05
        /// </summary>
        public decimal BenchMarkPremium05 { get; set; }

        /// <summary>
        ///  premium05
        /// </summary>
        public decimal Premium05 { get; set; }

        /// <summary>
        ///  kindName06
        /// </summary>
        public string KindName06 { get; set; }

        /// <summary>
        ///  amount06
        /// </summary>
        public decimal Amount06 { get; set; }

        /// <summary>
        ///  benchMarkPremium06
        /// </summary>
        public decimal BenchMarkPremium06 { get; set; }

        /// <summary>
        ///  premium06
        /// </summary>
        public decimal Premium06 { get; set; }

        /// <summary>
        ///  kindName07
        /// </summary>
        public string KindName07 { get; set; }

        /// <summary>
        ///  amount07
        /// </summary>
        public decimal Amount07 { get; set; }

        /// <summary>
        ///  benchMarkPremium07
        /// </summary>
        public decimal BenchMarkPremium07 { get; set; }

        /// <summary>
        ///  premium07
        /// </summary>
        public decimal Premium07 { get; set; }

        /// <summary>
        ///  kindName08
        /// </summary>
        public string KindName08 { get; set; }

        /// <summary>
        ///  amount08
        /// </summary>
        public decimal Amount08 { get; set; }

        /// <summary>
        ///  benchMarkPremium08
        /// </summary>
        public decimal BenchMarkPremium08 { get; set; }

        /// <summary>
        ///  premium08
        /// </summary>
        public decimal Premium08 { get; set; }

        /// <summary>
        ///  kindName09
        /// </summary>
        public string KindName09 { get; set; }

        /// <summary>
        ///  amount09
        /// </summary>
        public decimal Amount09 { get; set; }

        /// <summary>
        ///  benchMarkPremium09
        /// </summary>
        public decimal BenchMarkPremium09 { get; set; }

        /// <summary>
        ///  premium09
        /// </summary>
        public decimal Premium09 { get; set; }

        /// <summary>
        ///  kindName10
        /// </summary>
        public string KindName10 { get; set; }

        /// <summary>
        ///  amount10
        /// </summary>
        public decimal Amount10 { get; set; }

        /// <summary>
        ///  benchMarkPremium10
        /// </summary>
        public decimal BenchMarkPremium10 { get; set; }

        /// <summary>
        ///  premium10
        /// </summary>
        public decimal Premium10 { get; set; }

        /// <summary>
        ///  kindName11
        /// </summary>
        public string KindName11 { get; set; }

        /// <summary>
        ///  amount11
        /// </summary>
        public decimal Amount11 { get; set; }

        /// <summary>
        ///  benchMarkPremium11
        /// </summary>
        public decimal BenchMarkPremium11 { get; set; }

        /// <summary>
        ///  premium11
        /// </summary>
        public decimal Premium11 { get; set; }

        /// <summary>
        ///  kindName12
        /// </summary>
        public string KindName12 { get; set; }

        /// <summary>
        ///  amount12
        /// </summary>
        public decimal Amount12 { get; set; }

        /// <summary>
        ///  benchMarkPremium12
        /// </summary>
        public decimal BenchMarkPremium12 { get; set; }

        /// <summary>
        ///  premium12
        /// </summary>
        public decimal Premium12 { get; set; }

        /// <summary>
        ///  costRate01
        /// </summary>
        public string CostRate01 { get; set; }

        /// <summary>
        ///  costFee01
        /// </summary>
        public decimal CostFee01 { get; set; }

        /// <summary>
        ///  costRate02
        /// </summary>
        public string CostRate02 { get; set; }

        /// <summary>
        ///  costFee02
        /// </summary>
        public decimal CostFee02 { get; set; }

        /// <summary>
        ///  insertDate
        /// </summary>
        public DateTime InsertDate { get; set; }

        /// <summary>
        ///  proposalNo
        /// </summary>
        public string ProposalNo { get; set; }

    }
}