﻿using System;

namespace Ucfar.Application.Entity.SystemManage
{
    /// <summary>
    /// 作者:yekin-yu
    /// 日期：2016/11/22 11:06:46
    /// </summary>
    public class MBaseUser
    {
        /// <summary>
        ///  ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        ///  UserCode
        /// </summary>
        public string UserCode { get; set; }

        /// <summary>
        ///  Password
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        ///  IsAdmin
        /// </summary>
        public bool IsAdmin { get; set; }

        /// <summary>
        ///  RealName
        /// </summary>
        public string RealName { get; set; }

        /// <summary>
        ///  HeadIcon
        /// </summary>
        public string HeadIcon { get; set; }

        /// <summary>
        ///  Mobile
        /// </summary>
        public string Mobile { get; set; }

        /// <summary>
        ///  Telephone
        /// </summary>
        public string Telephone { get; set; }

        /// <summary>
        ///  SortCode
        /// </summary>
        public int SortCode { get; set; }

        /// <summary>
        ///  IsEnable
        /// </summary>
        public bool IsEnable { get; set; }

        /// <summary>
        ///  CreateDate
        /// </summary>
        public DateTime CreateDate { get; set; }
        public string OrganizeCode { get; set; }

    }
}