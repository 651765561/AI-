﻿namespace Ucfar.Application.Entity.SystemManage
{
    /// <summary>
    /// 作者:yekin-yu
    /// 日期：2016/12/13 13:55:14
    /// </summary>
    public class MtbSubDb
    {
        /// <summary>
        ///  ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        ///  SubDbCode
        /// </summary>
        public string SubDbCode { get; set; }

        /// <summary>
        ///  SubDbName
        /// </summary>
        public string SubDbName { get; set; }

        /// <summary>
        ///  SubDbIp
        /// </summary>
        public string SubDbIp { get; set; }

        /// <summary>
        ///  SubDbPort
        /// </summary>
        public string SubDbPort { get; set; }

        /// <summary>
        ///  SubDbUserName
        /// </summary>
        public string SubDbUserName { get; set; }

        /// <summary>
        ///  SubDbPassWord
        /// </summary>
        public string SubDbPassWord { get; set; }

        /// <summary>
        ///  IsOnline
        /// </summary>
        public bool IsOnline { get; set; }

        /// <summary>
        ///  OrgnizeCode
        /// </summary>
        public string OrgnizeCode { get; set; }

    }
}