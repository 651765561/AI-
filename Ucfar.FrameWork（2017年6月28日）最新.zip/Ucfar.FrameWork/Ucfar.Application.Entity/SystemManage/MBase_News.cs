﻿using System;

namespace Ucfar.Application.Entity.Model
{
    /// <summary>
    /// 作者:yekin-yu
    /// 日期：2017/2/13 13:19:35
    /// </summary>
    public class MBaseNews
    {
        /// <summary>
        ///  Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        ///  Title
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        ///  Memo
        /// </summary>
        public string Memo { get; set; }

        /// <summary>
        ///  CreateDate
        /// </summary>
        public DateTime CreateDate { get; set; }
        public string Sjhm { get; set; }
    }
}