﻿using System.ComponentModel;

namespace Ucfar.Application.Entity.SystemManage
{
    /// <summary>
    /// 用户个性化设置
    /// </summary>
    public class ConfigModel
    {
        /// <summary>
        /// 皮肤名称
        /// </summary>
        [Description("皮肤")]
        public Theme Theme { get; set; }

        /// <summary>
        /// 表现方式
        /// </summary>
        public string ShowType { get; set; }

    }

    public class Theme
    {
        /// <summary>
        /// 主题名称
        /// </summary>
        public string Title { get; set; }
        /// <summary>
        /// 主题路径名称
        /// </summary>
        public string Name { get; set; }
    }
}
