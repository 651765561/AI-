﻿using System;

namespace Ucfar.Application.Entity.SystemManage
{
    /// <summary>
    /// 作者:yekin-yu
    /// 日期：2017/6/2 15:28:28
    /// </summary>
    public class MtbCameraStatus
    {
        /// <summary>
        ///  Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        ///  CameraId
        /// </summary>
        public int CameraCode { get; set; }

        /// <summary>
        ///  CameraName
        /// </summary>
        public string CameraName { get; set; }

        /// <summary>
        ///  CameraIp
        /// </summary>
        public string CameraIp { get; set; }

        /// <summary>
        ///  CameraChannel
        /// </summary>
        public int CameraChannel { get; set; }

        /// <summary>
        ///  Stime
        /// </summary>
        public DateTime Stime { get; set; }

        /// <summary>
        /// 9 : 参数错(表中相应记录的某些字段有问题)8 : 登录失败7 : 播放不成功6 : 播放成功 : *不会出现, 天鹅设德拍摄有时会崩溃, 故不拍摄5 : 拍摄不成功4 : 拍摄成功 : *不会出现3 : 文件内容有误或不存在2 : 处理图像文件时申请内存出错1 : 图像不正常0 : 正常 Status
        /// </summary>
        public int Status { get; set; }

        /// <summary>
        /// 目前图像不正常时会有图片若有图片, 图片会上传到指定服务器, 如 :/ picture / 20160245 /192.168.0.64_123245_2.jpg其中 : 20160245为status.stime的年月日,192.168.0.64为status.ip123245为status.stime的时分秒 Picture
        /// </summary>
        public string Picture { get; set; }

        /// <summary>
        /// 1有, 0无 Notify
        /// </summary>
        public int Notify { get; set; }

    }
}