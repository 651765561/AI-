﻿namespace Ucfar.Application.Entity.SystemManage
{
     /// <summary>
    /// 作者:yekin-yu
    /// 日期：2016/11/22 11:06:46
    /// </summary>
    public class MParaCode
    {
        /// <summary>
        ///  ID
        /// </summary>
         public int ID{ get;set; }
        
        /// <summary>
        ///  LH
        /// </summary>
         public string LH{ get;set; }
        
        /// <summary>
        ///  FLH
        /// </summary>
         public string FLH{ get;set; }
        
        /// <summary>
        ///  NR
        /// </summary>
         public string NR{ get;set; }
        
    }
}