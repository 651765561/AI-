﻿namespace Ucfar.Application.Entity.SystemManage
{
    /// <summary>
    /// 作者:yekin-yu
    /// 日期：2016/12/15 10:27:04
    /// </summary>
    public class MtbSubServer
    {
        /// <summary>
        ///  ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        ///  SubCode
        /// </summary>
        public string SubCode { get; set; }

        /// <summary>
        ///  SubName
        /// </summary>
        public string SubName { get; set; }

        /// <summary>
        ///  SubIp
        /// </summary>
        public string SubIp { get; set; }

        /// <summary>
        ///  IsOnline
        /// </summary>
        public bool IsOnline { get; set; }

        /// <summary>
        ///  OrganizeCode
        /// </summary>
        public string OrganizeCode { get; set; }
        public bool IsEnable { get; set; }
        
    }
}