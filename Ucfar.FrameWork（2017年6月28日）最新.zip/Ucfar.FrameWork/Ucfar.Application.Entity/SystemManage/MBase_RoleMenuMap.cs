﻿namespace Ucfar.Application.Entity.SystemManage
{
     /// <summary>
    /// 作者:yekin-yu
    /// 日期：2016/11/22 11:06:46
    /// </summary>
    public class MBaseRoleMenuMap
    {
        /// <summary>
        ///  ID
        /// </summary>
         public int ID{ get;set; }
        
        /// <summary>
        ///  RoleCode
        /// </summary>
         public string RoleCode{ get;set; }
        
        /// <summary>
        ///  MenuCode
        /// </summary>
         public string MenuCode{ get;set; }
        
    }
}