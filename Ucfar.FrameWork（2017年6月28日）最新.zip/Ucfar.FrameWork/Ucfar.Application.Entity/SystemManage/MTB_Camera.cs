﻿namespace Ucfar.Application.Entity.SystemManage
{
    /// <summary>
    /// 作者:yekin-yu
    /// 日期：2017/5/19 13:50:36
    /// </summary>
    public class MtbCamera
    {
        /// <summary>
        ///  Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// 路口Id CrsCode
        /// </summary>
        public string CameraCode { get; set; }

        /// <summary>
        ///  CameraName
        /// </summary>
        public string CameraName { get; set; }

        /// <summary>
        /// 0:大华,1:海康,2:天地伟业,3:中星微,4:天鹅,5:NVR9000系列,6:大华移动,7:小天鹅移动,8:宇视 Sdk
        /// </summary>
        public int Sdk { get; set; }

        /// <summary>
        ///  Ip
        /// </summary>
        public string Ip { get; set; }

        /// <summary>
        ///  Port
        /// </summary>
        public int Port { get; set; }

        /// <summary>
        ///  UserName
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        ///  Pwd
        /// </summary>
        public string Pwd { get; set; }

        /// <summary>
        ///  Channel
        /// </summary>
        public int Channel { get; set; }

        /// <summary>
        /// 0:无;1:枪机;2:球机;3:卡口;4:电警; Type
        /// </summary>
        public int Type { get; set; }

        /// <summary>
        ///  Memo
        /// </summary>
        public string Memo { get; set; }

        /// <summary>
        /// 分布式服务器ID SubCode
        /// </summary>
        public string SubCode { get; set; }

        /// <summary>
        /// 字符通道识别参数 ChannelEx
        /// </summary>
        public string ChannelEx { get; set; }
        /// <summary>
        /// 是否可用
        /// </summary>
        public bool IsEnable { get; set; }
    }
}