﻿namespace Ucfar.Application.Entity.SystemManage
{
    /// <summary>
    /// 作者:yekin-yu
    /// 日期：2017/6/21 15:21:17
    /// </summary>
    public class MtbCrossingCamera
    {
        /// <summary>
        ///  Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        ///  CrsCode
        /// </summary>
        public string CrsCode { get; set; }

        /// <summary>
        ///  CrsIp
        /// </summary>
        public string CrsIp { get; set; }

        /// <summary>
        ///  CameraIp
        /// </summary>
        public string CameraIp { get; set; }

        /// <summary>
        ///  WhichOne
        /// </summary>
        public int WhichOne { get; set; }

    }
}