﻿namespace Ucfar.Application.Entity.SystemManage
{
     /// <summary>
    /// 作者:yekin-yu
    /// 日期：2016/11/22 11:06:45
    /// </summary>
    public class MBaseOrganize
    {
        /// <summary>
        ///  ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        ///  OrganizeCode
        /// </summary>
        public string OrganizeCode { get; set; }

        /// <summary>
        ///  ParentCode
        /// </summary>
        public string ParentCode { get; set; }

        /// <summary>
        ///  SortCode
        /// </summary>
        public int SortCode { get; set; }

        /// <summary>
        ///  OrganizeName
        /// </summary>
        public string OrganizeName { get; set; }

        /// <summary>
        ///  SubOrganizeName
        /// </summary>
        public string SubOrganizeName { get; set; }


    }
}