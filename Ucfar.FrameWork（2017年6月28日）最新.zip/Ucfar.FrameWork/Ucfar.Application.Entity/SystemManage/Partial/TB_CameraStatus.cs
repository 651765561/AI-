﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ucfar.Application.Entity.SystemManage.Partial
{
    /// <summary>
    /// TB_CameraStatus:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class TB_CameraStatus
    {
        public TB_CameraStatus()
        { }
        #region Model
        private int _id;
        private string _cameracode = "0";
        private string _cameraname;
        private string _cameraip = "127.0.0.1";
        private string _camerachannel = "1";
        private int _status = 0;
        private DateTime _stime = DateTime.Now;
        private string _picture = "0";
        private int _notify = 0;

        public string RowNumber
        {
            get;
            set;
        }
        public string StimeStr { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int Id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string CameraCode
        {
            set { _cameracode = value; }
            get { return _cameracode; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string CameraName
        {
            set { _cameraname = value; }
            get { return _cameraname; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string CameraIp
        {
            set { _cameraip = value; }
            get { return _cameraip; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string CameraChannel
        {
            set { _camerachannel = value; }
            get { return _camerachannel; }
        }
        /// <summary>
        /// 9 : 参数错(表中相应记录的某些字段有问题)8 : 登录失败7 : 播放不成功6 : 播放成功 : *不会出现, 天鹅设德拍摄有时会崩溃, 故不拍摄5 : 拍摄不成功4 : 拍摄成功 : *不会出现3 : 文件内容有误或不存在2 : 处理图像文件时申请内存出错1 : 图像不正常0 : 正常
        /// </summary>
        public int Status
        {
            set { _status = value; }
            get { return _status; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime Stime
        {
            set { _stime = value; }
            get { return _stime; }
        }
        public string StimeII
        {
            set;
            get;
        }
        /// <summary>
        /// 目前图像不正常时会有图片若有图片, 图片会上传到指定服务器, 如 :/ picture / 20160245 /192.168.0.64_123245_2.jpg其中 : 20160245为status.stime的年月日,192.168.0.64为status.ip123245为status.stime的时分秒
        /// </summary>
        public string Picture
        {
            set { _picture = value; }
            get { return _picture; }
        }
        /// <summary>
        /// 1有, 0无
        /// </summary>
        public int Notify
        {
            set { _notify = value; }
            get { return _notify; }
        }
        #endregion Model

    }
}
