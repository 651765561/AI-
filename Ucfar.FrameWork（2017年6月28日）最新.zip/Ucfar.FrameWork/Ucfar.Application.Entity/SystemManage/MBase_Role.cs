﻿namespace Ucfar.Application.Entity.SystemManage
{
    /// <summary>
    /// 作者:yekin-yu
    /// 日期：2016/11/22 11:06:45
    /// </summary>
    public class MBaseRole
    {
        /// <summary>
        ///  ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        ///  RoleCode
        /// </summary>
        public string RoleCode { get; set; }

        /// <summary>
        ///  RoleName
        /// </summary>
        public string RoleName { get; set; }

        /// <summary>
        ///  Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        ///  SortCode
        /// </summary>
        public int SortCode { get; set; }
        public int IsDefault { get; set; }
    }
}