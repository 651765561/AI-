﻿namespace Ucfar.Application.Entity.SystemManage
{
    /// <summary>
    /// 作者:yekin-yu
    /// 日期：2016/12/15 10:28:31
    /// </summary>
    public class MtbSubServerRoleMap
    {
        /// <summary>
        ///  ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        ///  SubCode
        /// </summary>
        public string SubCode { get; set; }

        /// <summary>
        ///  RoleCode
        /// </summary>
        public string RoleCode { get; set; }

    }
}