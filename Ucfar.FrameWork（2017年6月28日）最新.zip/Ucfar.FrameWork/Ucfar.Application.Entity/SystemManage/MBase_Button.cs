﻿namespace Ucfar.Application.Entity.SystemManage
{
     /// <summary>
    /// 作者:yekin-yu
    /// 日期：2016/11/22 11:06:44
    /// </summary>
    public class MBaseButton
    {
        /// <summary>
        ///  ID
        /// </summary>
         public int ID{ get;set; }
        
        /// <summary>
        ///  ButtonCode
        /// </summary>
         public string ButtonCode{ get;set; }
        
        /// <summary>
        ///  ButtonName
        /// </summary>
         public string ButtonName{ get;set; }
        
        /// <summary>
        ///  SortCode
        /// </summary>
         public int SortCode{ get;set; }
        
        /// <summary>
        ///  Description
        /// </summary>
         public string Description{ get;set; }
        
        /// <summary>
        ///  ButtonIcon
        /// </summary>
         public string ButtonIcon{ get;set; }
        
    }
}