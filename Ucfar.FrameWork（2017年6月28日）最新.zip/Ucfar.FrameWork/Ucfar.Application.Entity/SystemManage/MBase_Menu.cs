﻿namespace Ucfar.Application.Entity.SystemManage
{
     /// <summary>
    /// 作者:yekin-yu
    /// 日期：2016/11/22 11:06:45
    /// </summary>
    public class MBaseMenu
    {
        /// <summary>
        ///  ID
        /// </summary>
         public int ID{ get;set; }
        
        /// <summary>
        ///  MenuCode
        /// </summary>
         public string MenuCode{ get;set; }
        
        /// <summary>
        ///  ParentCode
        /// </summary>
         public string ParentCode{ get;set; }
        
        /// <summary>
        ///  MenuName
        /// </summary>
         public string MenuName{ get;set; }
        
        /// <summary>
        ///  URL
        /// </summary>
         public string URL{ get;set; }
        
        /// <summary>
        ///  IconClass
        /// </summary>
         public string IconClass{ get;set; }
        
        /// <summary>
        ///  SortCode
        /// </summary>
         public int SortCode{ get;set; }
        
        /// <summary>
        ///  IsVisible
        /// </summary>
         public bool IsVisible{ get;set; }
        
    }
}