﻿namespace UCFAR.Util.Dapper
{
    /// <summary>
    /// redis options
    /// </summary>
    public class DapperOptions
    {
        public string ConnectionString { get; set; }
    }
}
