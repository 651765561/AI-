﻿namespace AI
{
    public class AppSettingsConfig
    {
        public string SubCode { get; set; }
    }
}
